import sys
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
d = Document(sys.argv[1]); FS = float(sys.argv[3]) if len(sys.argv) > 3 else 8.5
def border(cell, **kw):
    tcPr = cell._tc.get_or_add_tcPr(); b = tcPr.find(qn('w:tcBorders'))
    if b is None:
        b = OxmlElement('w:tcBorders')
        w = tcPr.find(qn('w:tcW'))
        (w.addnext(b) if w is not None else tcPr.insert(0, b))
    for edge, val in kw.items():
        e = OxmlElement(f'w:{edge}'); e.set(qn('w:val'), 'single'); e.set(qn('w:sz'), str(val)); e.set(qn('w:color'), '000000'); b.append(e)
for t in d.tables:
    n = len(t.rows)
    for i, row in enumerate(t.rows):
        for c in row.cells:
            for p in c.paragraphs:
                pf = p.paragraph_format; pf.line_spacing = 1.0; pf.space_after = Pt(1); pf.space_before = Pt(1); pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for r in p.runs: r.font.size = Pt(FS); r.font.name = 'Times New Roman'; r.font.bold = (i == 0)
            if i == 0: border(c, top=10, bottom=6)
            if i == n - 1: border(c, bottom=10)
for t in d.tables:
    nx = t._tbl.getnext()
    if nx is not None and nx.tag == qn('w:p'):
        pPr = nx.get_or_add_pPr(); sp = pPr.find(qn('w:spacing'))
        if sp is None: sp = OxmlElement('w:spacing'); pPr.append(sp)
        sp.set(qn('w:before'), '160')
for p in d.paragraphs:
    if p._p.xpath('.//w:drawing'):
        p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.keep_with_next = True
for sec in d.sections:
    fp = sec.footer.paragraphs[0] if sec.footer.paragraphs else sec.footer.add_paragraph()
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER; r = fp.add_run()
    for tag, txt in (('begin', None), (None, 'PAGE'), ('end', None)):
        if tag: f = OxmlElement('w:fldChar'); f.set(qn('w:fldCharType'), tag); r._r.append(f)
        else: it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = txt; r._r.append(it)
    r.font.size = Pt(9)
d.save(sys.argv[2])
