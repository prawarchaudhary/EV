"""Simulation figure (main text) and supplementary figures S1 to S9, in the common Times New Roman style."""
import sys, json
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
sys.path.insert(0, "code")
import figures as F
import prep, framework as fw
C, dates, panel, save, fmt_dates = F.C, F.dates, F.panel, F.save, F.fmt_dates
EST = {"Proposed (constrained, CV kappa)": ("Proposed", C["blue"]),
       "Unconstrained smooth (same kappa)": ("Unconstrained smooth", C["orange"]),
       "Two-stage window (w = 6)": ("Two-stage window", C["aqua"])}
SCA, SCB = "A: transient loss response", "B: persistent phase-specific subsidy"
LAB = {"x": "$x$", "x2": "$x^2$", "S1": "$S^{(1)}$", "S2": "$S^{(2)}$", "G": "$G$", "L": "$L$",
       "pre": "pre", "fest": "fest", "march": "March", "covid": "COVID"}
MK = {"India e-2W": "India e-2W", "China NEV": "China NEV"}

def boxes(ax, runs, sc, term, truth, ylim=None):
    pos, k = [], 0
    for j, m in enumerate((0.5, 1.0, 2.0)):
        for i, (e, (lab, col)) in enumerate(EST.items()):
            v = runs[(runs.scenario == sc) & (runs.noise_mult == m) & (runs.estimator == e)]["b_" + term].values
            p = j * 4 + i; bp = ax.boxplot(v, positions=[p], widths=0.7, patch_artist=True, showfliers=False,
                                         medianprops=dict(color=C["ink"], lw=1), whiskerprops=dict(color=col),
                                         capprops=dict(color=col), boxprops=dict(facecolor=col + "55", edgecolor=col))
    ax.axhline(truth, color=C["ink"], ls="--", lw=0.9)
    ax.set_xticks([1, 5, 9]); ax.set_xticklabels(["0.5$\\hat\\sigma$", "1.0$\\hat\\sigma$", "2.0$\\hat\\sigma$"])
    ax.set_xlabel("noise standard deviation"); ax.set_xlim(-0.8, 10.8)
    if ylim: ax.set_ylim(*ylim)

def fig_simulation():
    runs = pd.read_csv("results/simulation_runs.csv"); tr = json.load(open("results/simulation_truth.json"))["truth"]
    ov = pd.read_csv("results/supp_simulation_overview.csv")
    fig, axs = plt.subplots(2, 2, figsize=(7.2, 5.6)); fig.subplots_adjust(hspace=0.55, wspace=0.32)
    ax = axs[0, 0]; boxes(ax, runs, SCB, "S1", tr[SCB]["S1"]); ax.set_ylabel("estimate of $\\beta_{S^{(1)}}$")
    ax.set_title("Scenario B: persistent subsidy effect", loc="left"); panel(ax, "a")
    ax = axs[0, 1]; boxes(ax, runs, SCA, "L", tr[SCA]["L"]); ax.set_ylabel("estimate of $\\beta_{L}$")
    ax.set_title("Scenario A: transient loss response", loc="left"); panel(ax, "b")
    ax = axs[1, 0]
    for i, (e, (lab, col)) in enumerate(EST.items()):
        g = ov[(ov.scenario == SCA) & (ov.estimator == e)]
        ax.bar(np.arange(3) + (i - 1) * 0.26, 100 * g.subsidy_selected.values, 0.24, color=col, label=lab)
    ax.set_xticks(range(3)); ax.set_xticklabels(["0.5$\\hat\\sigma$", "1.0$\\hat\\sigma$", "2.0$\\hat\\sigma$"])
    ax.set_ylabel("replicates with a subsidy term (%)"); ax.set_ylim(0, 112); ax.set_xlabel("noise standard deviation")
    ax.set_title("Scenario A: spurious subsidy terms", loc="left"); panel(ax, "c")
    ax.legend(fontsize=7, loc="upper center", ncol=3, bbox_to_anchor=(1.12, -0.28), frameon=False)
    ax = axs[1, 1]
    for e, (lab, col) in EST.items():
        for sc, ls, mk in ((SCA, "-", "o"), (SCB, "--", "s")):
            g = ov[(ov.scenario == sc) & (ov.estimator == e)]
            ax.plot([0.5, 1, 2], g.share_mae_pp, ls=ls, marker=mk, ms=3.5, color=col, lw=1.2)
    ax.plot([], [], "k-", marker="o", ms=3.5, label="scenario A"); ax.plot([], [], "k--", marker="s", ms=3.5, label="scenario B")
    ax.legend(fontsize=7, loc="upper left"); ax.set_xticks([0.5, 1, 2]); ax.set_xticklabels(["0.5$\\hat\\sigma$", "1.0$\\hat\\sigma$", "2.0$\\hat\\sigma$"])
    ax.set_ylabel("share error (percentage points)"); ax.set_xlabel("noise standard deviation")
    ax.set_title("Recovery of the noise-free share", loc="left"); panel(ax, "d")
    save(fig, "fig_simulation.png")

# ---------------- supplementary ----------------
def figS_learning():
    L = pd.read_csv("results/supp_learning_paths.csv")
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.8)); fig.subplots_adjust(wspace=0.25)
    cols = {"Proposed smooth TV": C["blue"], "Two-stage window TV (w = 6)": C["aqua"], "Fixed coefficients": C["orange"]}
    for ax, mk, lab in zip(axs, ("India e-2W", "China NEV"), "ab"):
        g = L[L.market == mk]; o = g[g.model == "Proposed smooth TV"]
        ax.plot(dates(o.yyyymm), 100 * o.obs, "o", ms=2.6, color=C["ink"], label="observed")
        for m, col in cols.items():
            h = g[g.model == m]; ax.plot(dates(h.yyyymm), 100 * h.fit, color=col, lw=1.2, label=m)
        ax.set_title(mk, loc="left"); ax.set_ylabel("electric share of registrations (%)"); panel(ax, lab)
        fmt_dates(ax, short=(mk == "China NEV"))
    axs[0].legend(fontsize=7, loc="upper left"); save(fig, "sfig5_learning.png")

def figS_residuals():
    fig, axs = plt.subplots(2, 3, figsize=(7.2, 4.4)); fig.subplots_adjust(hspace=0.6, wspace=0.35)
    for r, (mk, f) in enumerate((("India e-2W", "india"), ("China NEV", "china"))):
        d = pd.read_csv(f"results/{f}_decomposition.csv"); e = np.log(d.s / (1 - d.s)) - np.log(d.fit / (1 - d.fit))
        ax = axs[r, 0]; ax.axhline(0, color=C["ink2"], lw=0.7); ax.plot(dates(d.yyyymm), e, color=C["blue"], lw=1, marker="o", ms=2)
        ax.set_ylabel("logit residual"); ax.set_title(mk, loc="left"); fmt_dates(ax, short=(r == 1)); panel(ax, "abcdef"[3 * r])
        ax = axs[r, 1]; n = len(e); lags = np.arange(1, 13); ev = e - e.mean()
        acf = [np.sum(ev[k:] * ev[:-k].values) / np.sum(ev ** 2) for k in lags] if True else None
        ax.bar(lags, acf, color=C["blue"], width=0.6); ax.axhline(1.96 / np.sqrt(n), color=C["orange"], ls="--", lw=0.8)
        ax.axhline(-1.96 / np.sqrt(n), color=C["orange"], ls="--", lw=0.8); ax.axhline(0, color=C["ink2"], lw=0.6)
        ax.set_xlabel("lag (months)"); ax.set_ylabel("autocorrelation"); ax.set_title("Autocorrelation", loc="left"); panel(ax, "abcdef"[3 * r + 1])
        ax = axs[r, 2]; (q, v), _ = stats.probplot(e, dist="norm")
        ax.plot(q, v, "o", ms=2.6, color=C["blue"]); lo, hi = q.min(), q.max(); ax.plot([lo, hi], [lo * e.std() + e.mean(), hi * e.std() + e.mean()], color=C["orange"], lw=1)
        ax.set_xlabel("normal quantile"); ax.set_ylabel("residual quantile"); ax.set_title("Normal Q-Q", loc="left"); panel(ax, "abcdef"[3 * r + 2])
    save(fig, "sfig4_residuals.png")

def figS_bootstrap():
    z = np.load("results/bootstrap_draws.npz", allow_pickle=True)
    ci = pd.read_csv("results/india_coefficients.csv", index_col=0); cc = pd.read_csv("results/china_coefficients.csv", index_col=0)
    sets = [("India e-2W", z["india"], list(z["india_terms"]), ci), ("China NEV", z["china"], list(z["china_terms"]), cc)]
    show = [(mk, B, t, c, k) for mk, B, t, c in sets for k in ("S1", "S2", "L", "pre", "fest", "march", "covid") if k in t and (np.abs(B[:, t.index(k)]) > 0).mean() > 0]
    n = len(show); nc = 4; nr = int(np.ceil(n / nc))
    fig, axs = plt.subplots(nr, nc, figsize=(7.2, 1.75 * nr)); fig.subplots_adjust(hspace=0.75, wspace=0.35); axs = axs.ravel()
    for ax, (mk, B, t, c, k) in zip(axs, show):
        v = B[:, t.index(k)]; ax.hist(v, bins=25, color=C["blue"] + "88", edgecolor=C["blue"], lw=0.4)
        ax.axvline(c.loc[k, "estimate"], color=C["orange"], lw=1.2); ax.axvline(0, color=C["ink2"], lw=0.6, ls=":")
        ax.set_title(f"{mk}, {LAB[k]}", loc="left", fontsize=8); ax.set_yticks([]); ax.tick_params(labelsize=7)
        ax.text(0.98, 0.95, f"retained {100 * (v != 0).mean():.0f}%", transform=ax.transAxes, ha="right", va="top", fontsize=6.5, color=C["ink2"])
    for ax in axs[n:]: ax.set_axis_off()
    save(fig, "sfig3_bootstrap.png")

def figS_configs():
    fc = pd.read_csv("results/fold_configs.csv")
    fig, axs = plt.subplots(2, 2, figsize=(7.2, 5.2), gridspec_kw=dict(width_ratios=[1.6, 1])); fig.subplots_adjust(hspace=0.55, wspace=0.35)
    for r, mk in enumerate(("India e-2W", "China NEV")):
        g = fc[fc.market == mk].copy(); g["cfg"] = g.baseline_forecaster + ", $\\kappa$=" + g.kappa.map(lambda v: f"{v:g}")
        P = g.pivot_table(index="cfg", columns="fold", values="test_mae_pp", sort=False)
        ax = axs[r, 0]; im = ax.imshow(P.values, aspect="auto", cmap="Blues", vmin=0)
        ax.set_yticks(range(len(P))); ax.set_yticklabels(P.index, fontsize=5.6); ax.set_xticks(range(P.shape[1]))
        ax.set_xticklabels([f"{int(f) // 100}-{int(f) % 100:02d}" for f in P.columns], fontsize=7); ax.grid(False)
        W = g.pivot_table(index="cfg", columns="fold", values="weight", sort=False)
        for j in range(P.shape[1]):
            i = int(np.nanargmax(W.values[:, j])); ax.add_patch(plt.Rectangle((j - 0.5, i - 0.5), 1, 1, fill=False, ec=C["orange"], lw=1.3))
            i2 = int(np.nanargmin(P.values[:, j])); ax.plot(j, i2, "*", color=C["ink"], ms=5)
        cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02); cb.set_label("test MAE (pp)", fontsize=7); cb.ax.tick_params(labelsize=6)
        ax.set_title(f"{mk}: test error by configuration and fold", loc="left", fontsize=8.5); ax.set_xlabel("first test month"); panel(ax, "ac"[r])
        ax = axs[r, 1]; ax.scatter(g.val_mae_pp, g.test_mae_pp, s=12 + 120 * g.weight, color=C["blue"] + "99", edgecolor=C["blue"], lw=0.4)
        lim = max(g.val_mae_pp.max(), g.test_mae_pp.max()) * 1.05; ax.plot([0, lim], [0, lim], color=C["ink2"], ls="--", lw=0.7)
        rho = stats.spearmanr(g.val_mae_pp, g.test_mae_pp).correlation
        ax.text(0.04, 0.95, f"Spearman $\\rho$ = {rho:.2f}", transform=ax.transAxes, va="top", fontsize=7)
        ax.set_xlabel("validation MAE (pp)"); ax.set_ylabel("test MAE (pp)"); ax.set_title("Validation versus test", loc="left", fontsize=8.5); panel(ax, "bd"[r])
    save(fig, "sfig1_configurations.png")

def figS_folds():
    fo = pd.read_csv("results/forecasts.csv"); di, dc = prep.india(), prep.china()
    models = {"Proposed (combined smooth TV)": ("Proposed", C["blue"], "-"), "Two-stage window TV": ("Two-stage window", C["aqua"], "-"),
              "Fixed coefficients": ("Fixed coefficients", C["orange"], "-"), "SARIMAX": ("SARIMAX", C["violet"], "--"),
              "GBM": ("GBM", C["yellow"], "--"), "Persistence": ("Persistence", C["ink2"], ":")}
    folds = [(mk, f) for mk in ("India e-2W", "China NEV") for f in fo[fo.market == mk].fold.unique()]
    fig, axs = plt.subplots(3, 4, figsize=(7.2, 6.2)); fig.subplots_adjust(hspace=0.75, wspace=0.38); axs = axs.ravel()
    for ax, (mk, f) in zip(axs, folds):
        d = di if mk == "India e-2W" else dc; idx = np.where(d.yyyymm.values == f)[0][0]; w = d.iloc[max(0, idx - 9): idx + 3]
        ax.plot(dates(w.yyyymm), 100 * w.s, "o-", color=C["ink"], ms=2.2, lw=0.8)
        for m, (lab, col, ls) in models.items():
            g = fo[(fo.market == mk) & (fo.fold == f) & (fo.model == m)].sort_values("h")
            ax.plot(dates(g.yyyymm), 100 * g.pred, ls=ls, color=col, lw=1.2, marker="o", ms=2)
        ax.axvline(dates([f])[0] - pd.Timedelta(days=15), color=C["ink2"], lw=0.6, ls=":")
        ax.set_title(f"{mk.split()[0]}, origin {int(f) // 100}-{int(f) % 100:02d}", loc="left", fontsize=7.5)
        ax.tick_params(labelsize=6); fmt_dates(ax, short=True); ax.tick_params(axis="x", labelsize=5.5)
    for ax in axs[len(folds):]: ax.set_axis_off()
    hs = [plt.Line2D([], [], color=C["ink"], marker="o", ms=2.5, lw=0.8, label="observed")] + \
         [plt.Line2D([], [], color=c, ls=ls, lw=1.2, label=l) for l, c, ls in models.values()]
    axs[-1].legend(handles=hs, fontsize=7, loc="center"); axs[0].set_ylabel("share (%)"); axs[4].set_ylabel("share (%)"); axs[8].set_ylabel("share (%)")
    save(fig, "sfig6_fold_paths.png")

def figS_coverage():
    iv = pd.read_csv("results/intervals.csv"); iv["width"] = 100 * (iv.hi - iv.lo)
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.7)); fig.subplots_adjust(wspace=0.3)
    for ax, mk, lab in zip(axs, ("India e-2W", "China NEV"), "ab"):
        g = iv[iv.market == mk].sort_values("yyyymm")
        ax.vlines(dates(g.yyyymm), 100 * g.lo, 100 * g.hi, color=C["blue"] + "88", lw=4)
        ax.plot(dates(g.yyyymm[g.covered]), 100 * g.obs[g.covered], "o", color=C["ink"], ms=3, label="covered")
        ax.plot(dates(g.yyyymm[~g.covered]), 100 * g.obs[~g.covered], "x", color=C["orange"], ms=5, mew=1.4, label="not covered")
        ax.set_title(f"{mk}: coverage {100 * g.covered.mean():.0f}% of {len(g)}", loc="left"); ax.set_ylabel("share (%)")
        fmt_dates(ax, short=True); panel(ax, lab)
    axs[0].legend(fontsize=7, loc="upper left"); save(fig, "sfig7_coverage.png")

def figS_counterfactual():
    di = prep.india(); n = di.n.values
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.9)); fig.subplots_adjust(wspace=0.3)
    cols = {"Actual path": C["ink"], "Maintain May 2023 level": C["blue"], "Linear taper to zero by June 2025": C["aqua"], "Abrupt withdrawal in June 2023": C["orange"]}
    P = pd.read_csv("results/counterfactual_paths_k100.csv"); ax = axs[0]
    for k, col in cols.items(): ax.plot(dates(P.yyyymm), 100 * P[k], color=col, lw=1.3, label=k)
    ax.set_ylabel("simulated share (%)"); ax.set_title("Paths at $\\kappa$ = 100", loc="left"); fmt_dates(ax, short=True); panel(ax, "a")
    ax.legend(fontsize=6.5, loc="upper left")
    ax = axs[1]; i0 = int(np.where(di.yyyymm == 202306)[0][0])
    for kap, ls in ((10, "-"), (100, "--"), (1000, ":")):
        P = pd.read_csv(f"results/counterfactual_paths_k{kap}.csv"); base = P["Abrupt withdrawal in June 2023"] * n[i0:]
        for k in ("Actual path", "Maintain May 2023 level", "Linear taper to zero by June 2025"):
            ax.plot(dates(P.yyyymm), np.cumsum(P[k] * n[i0:] - base) / 1e5, ls=ls, color=cols[k], lw=1.2)
    ax.plot([], [], "k-", label="$\\kappa$ = 10"); ax.plot([], [], "k--", label="$\\kappa$ = 100"); ax.plot([], [], "k:", label="$\\kappa$ = 1000")
    ax.axhline(0, color=C["ink2"], lw=0.6); ax.legend(fontsize=6.5, loc="upper left")
    ax.set_ylabel("cumulative additional EVs (lakh)"); ax.set_title("Relative to abrupt withdrawal", loc="left"); fmt_dates(ax, short=True); panel(ax, "b")
    save(fig, "sfig9_counterfactual_bracket.png")

def figS_simulation_all():
    runs = pd.read_csv("results/simulation_runs.csv"); tr = json.load(open("results/simulation_truth.json"))["truth"]
    terms = ["S1", "S2", "L", "pre", "fest", "march", "covid"]
    fig, axs = plt.subplots(2, 7, figsize=(7.4, 3.9), sharey=False); fig.subplots_adjust(hspace=0.55, wspace=0.55)
    for r, sc in enumerate((SCA, SCB)):
        g = runs[(runs.scenario == sc) & (runs.noise_mult == 1.0)]
        for c, k in enumerate(terms):
            ax = axs[r, c]
            for i, (e, (lab, col)) in enumerate(EST.items()):
                v = g[g.estimator == e]["b_" + k].values
                ax.boxplot(v, positions=[i], widths=0.6, patch_artist=True, showfliers=False, medianprops=dict(color=C["ink"], lw=0.8),
                           whiskerprops=dict(color=col), capprops=dict(color=col), boxprops=dict(facecolor=col + "55", edgecolor=col))
            ax.axhline(tr[sc][k], color=C["ink"], ls="--", lw=0.8); ax.set_xticks([]); ax.tick_params(labelsize=5.8)
            ax.set_title(LAB[k], fontsize=8)
        axs[r, 0].set_ylabel(("Scenario A" if r == 0 else "Scenario B") + "\nestimate", fontsize=7.5)
    hs = [plt.Rectangle((0, 0), 1, 1, fc=col + "55", ec=col, label=lab) for lab, col in EST.values()]
    fig.legend(handles=hs, loc="lower center", ncol=3, fontsize=7, frameon=False, bbox_to_anchor=(0.5, -0.02))
    save(fig, "sfig2_simulation_terms.png")

def figS_robust_factor():
    rb = pd.read_csv("results/robustness.csv"); rb["vehicle"] = rb.kwh
    facs = [("vehicle", "vehicle (kWh)"), ("k_ref", "reference window (months)"),
                                                         ("kappa", "smoothness $\\kappa$"), ("tau", "threshold $\\tau$")]
    fig, axs = plt.subplots(2, 4, figsize=(7.2, 3.8)); fig.subplots_adjust(hspace=0.6, wspace=0.4)
    for r, (k, nm) in enumerate((("L", "$\\beta_L$"), ("S1", "$\\beta_{S^{(1)}}$"))):
        for c, (f, fl) in enumerate(facs):
            ax = axs[r, c]; levs = sorted(rb[f].unique())
            ax.boxplot([rb[rb[f] == l][k].values for l in levs], widths=0.55, patch_artist=True, showfliers=True,
                       flierprops=dict(ms=2), medianprops=dict(color=C["ink"]), boxprops=dict(facecolor=C["blue"] + "55", edgecolor=C["blue"]))
            ax.set_xticks(range(1, len(levs) + 1)); ax.set_xticklabels([f"{l / 1e5:g}" if f == "price" else f"{l:g}" for l in levs], fontsize=6.5)
            ax.set_xlabel(fl, fontsize=7); ax.tick_params(axis="y", labelsize=6.3)
            if c == 0: ax.set_ylabel(nm)
    save(fig, "sfig8_robustness_factor.png")

if __name__ == "__main__":
    which = sys.argv[1:] or ["simulation", "S_learning", "S_residuals", "S_bootstrap", "S_configs", "S_folds", "S_coverage",
                             "S_counterfactual", "S_simulation_all", "S_robust_factor"]
    for w in which:
        globals()["fig" + ("_" + w if not w.startswith("S_") else "S" + w[1:])](); print(w)
