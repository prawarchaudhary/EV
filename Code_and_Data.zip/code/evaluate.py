"""Rolling-origin evaluation with validation-based configuration selection.

For each test fold (H months) the configuration of the proposed model is selected on the two
preceding validation folds of equal length (models refitted on data before each validation
origin), then refitted on all data before the test origin. An oracle configuration chosen on
the test fold itself is reported separately as a post hoc benchmark, not as a forecast.
"""
import sys, json, itertools, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "code")
import prep, framework as fw
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from statsmodels.tsa.statespace.sarimax import SARIMAX
warnings.filterwarnings("ignore")

TERMS = ["x", "x2", "S1", "S2", "G", "L", "pre", "fest", "march", "covid"]
EXOG = ["S", "G", "L", "pre", "fest", "march", "covid"]
H = 3

def proposed_grid():
    for kappa, am in itertools.product([3.0, 10.0, 30.0], ["last", "trend", "rf", "netlin"]):
        yield dict(mode="smooth", kappa=kappa, a_model=am)

def block_grid():
    for w in [6, 9, 12]:
        yield dict(mode="block", window=w, a_model="last")

def run_model(cfg, d_tr, d_te, beta_prior=None):
    lib = fw.library(d_tr, TERMS)
    terms = [t for t in TERMS if lib[t].std() > 0]
    if beta_prior is not None:   # transfer: policy coefficients fixed from another market
        d_tr = d_tr.copy(); d_te = d_te.copy()
        off_tr = sum(beta_prior[k] * d_tr[k] for k in beta_prior)
        d_tr["y"] = d_tr.y - off_tr
        terms = [t for t in terms if t not in beta_prior]
    m = fw.TVPayoffModel(terms, **cfg).fit(d_tr)
    if beta_prior is None:
        return m.forecast(d_te)
    # forecast with prior policy effects added back
    hist = m.d; M, E = hist.M.values[-1], hist.E.values[-1]; out = []
    S_all = np.r_[hist.S.values, d_te.S.values]; since = fw.months_since_change(S_all)
    for h in range(len(d_te)):
        row = d_te.iloc[[h]].copy(); row["xlag"] = E / M
        F = np.c_[row.xlag.values, since[len(hist) + h], row.S.values]
        u = m.a_forecast(h + 1, F, row.xlag.values[0]) + m.payoff_fixed(row)[0] \
            + sum(beta_prior[k] * row[k].values[0] for k in beta_prior)
        s = fw.sigma(u); out.append(s); M += row.n.values[0]; E += s * row.n.values[0]
    return np.array(out)

# ---------------- baselines ----------------
def persistence(d_tr, d_te): return np.repeat(d_tr.s.values[-1], len(d_te))

def logistic_trend(d_tr, d_te, k=24):
    k = min(k, len(d_tr)); t = d_tr.t.values[-k:]; c = np.polyfit(t, d_tr.y.values[-k:], 1)
    return fw.sigma(np.polyval(c, d_te.t.values))

def _feat(d, ylag):
    return np.c_[d[EXOG].values, d.xlag.values, ylag]

def recursive_ml(model, d_tr, d_te):
    X = _feat(d_tr.iloc[1:], d_tr.y.values[:-1]); y = d_tr.y.values[1:]
    sc = StandardScaler().fit(X); model.fit(sc.transform(X), y)
    ylag = d_tr.y.values[-1]; M, E = d_tr.M.values[-1], d_tr.E.values[-1]; out = []
    for h in range(len(d_te)):
        row = d_te.iloc[[h]].copy(); row["xlag"] = E / M
        yh = model.predict(sc.transform(_feat(row, [ylag])))[0]
        s = fw.sigma(yh); out.append(s); ylag = yh; M += row.n.values[0]; E += s * row.n.values[0]
    return np.array(out)

def gbm(d_tr, d_te):
    return recursive_ml(GradientBoostingRegressor(n_estimators=500, learning_rate=0.02, max_depth=3,
                                                  subsample=0.9, min_samples_leaf=3, random_state=0), d_tr, d_te)

def mlp(d_tr, d_te):
    preds = [recursive_ml(MLPRegressor(hidden_layer_sizes=(32, 16), alpha=1e-2, max_iter=5000,
                                       random_state=s), d_tr, d_te) for s in range(5)]
    return np.mean(preds, 0)

def sarimax(d_tr, d_te):
    ex = [c for c in EXOG if d_tr[c].std() > 0]
    m = SARIMAX(d_tr.y.values, exog=d_tr[ex].values, order=(1, 1, 0), trend="n").fit(disp=False)
    return fw.sigma(m.forecast(len(d_te), exog=d_te[ex].values))

BASELINES = {"Persistence": persistence, "Logistic trend": logistic_trend, "SARIMAX": sarimax,
             "GBM": gbm, "MLP": mlp}

def mae(a, b): return float(np.mean(np.abs(np.asarray(a) - np.asarray(b))))

def evaluate(d, test_starts, beta_prior=None, label=""):
    rows, sel_log = [], []
    for t0 in test_starts:
        d_tr, d_te = d.iloc[:t0], d.iloc[t0:t0 + H]
        def val_score(cfg):
            sc = []
            for v0 in (t0 - 2 * H, t0 - H):
                sc.append(mae(run_model(cfg, d.iloc[:v0], d.iloc[v0:v0 + H], beta_prior), d.s.values[v0:v0 + H]))
            return np.mean(sc)
        res = {}
        grid = list(proposed_grid())
        vs = [val_score(c) for c in grid]; best = grid[int(np.argmin(vs))]
        p = run_model(best, d_tr, d_te, beta_prior); res["Proposed (smooth TV)"] = p
        test_sc = [mae(run_model(c, d_tr, d_te, beta_prior), d_te.s) for c in grid]
        res["Proposed, oracle configuration"] = run_model(grid[int(np.argmin(test_sc))], d_tr, d_te, beta_prior)
        bg = list(block_grid()); bvs = [val_score(c) for c in bg]; bb = bg[int(np.argmin(bvs))]
        res["Two-stage window TV"] = run_model(bb, d_tr, d_te, beta_prior)
        res["Fixed coefficients"] = run_model(dict(mode="fixed"), d_tr, d_te, beta_prior)
        for k, f in BASELINES.items(): res[k] = f(d_tr, d_te)
        for k, p in res.items():
            for h in range(len(d_te)):
                rows.append(dict(market=label, fold=int(d_te.yyyymm.values[0]), h=h + 1, model=k,
                                 yyyymm=int(d_te.yyyymm.values[h]), obs=float(d_te.s.values[h]), pred=float(p[h])))
        sel_log.append(dict(fold=int(d_te.yyyymm.values[0]), proposed=best, block=bb))
    return pd.DataFrame(rows), sel_log

if __name__ == "__main__":
    di = prep.india()
    t_india = [int(np.where(di.yyyymm == m)[0][0]) for m in (202401, 202404, 202407, 202410, 202501, 202504)]
    ri, si = evaluate(di, t_india, label="India e-2W")
    dc = prep.china()
    t_china = [int(np.where(dc.yyyymm == m)[0][0]) for m in (202509, 202512, 202603, 202606)]
    rc, sc_ = evaluate(dc, t_china, label="China NEV")
    # transfer: India policy coefficients (full-sample fit on India only) applied to China
    a_in, b_in = fw.fit_smooth(di, TERMS, kappa=10.0, tau=0.02)
    prior = {k: float(b_in[k]) for k in ("S", "G", "L", "pre") if b_in[k] != 0}
    rt, st = evaluate(dc, t_china, beta_prior=prior, label="China NEV (India policy prior)")
    out = pd.concat([ri, rc, rt]); out.to_csv("results_forecasts.csv", index=False)
    out["ae"] = (out.pred - out.obs).abs() * 100
    summ = out.groupby(["market", "model"]).ae.mean().unstack(0).round(3)
    print(summ.to_string())
    json.dump(dict(india=si, china=sc_, china_transfer=st, prior=prior), open("results_selection.json", "w"), indent=1, default=str)
