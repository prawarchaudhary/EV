"""Publication figures. Every plotted quantity is read from results/ or data/."""
import sys, json
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
sys.path.insert(0, "code")
import prep, framework as fw

import glob, os
import matplotlib.font_manager as fm
for f in glob.glob(os.path.expanduser("~/.fonts/*.ttf")): fm.fontManager.addfont(f)
C = dict(blue="#2a78d6", orange="#eb6834", aqua="#1baf7a", yellow="#eda100", magenta="#e87ba4",
         green="#008300", violet="#6250d6", red="#e34948", ink="#0b0b0b", ink2="#52514e", grid="#e4e3df")
plt.rcParams.update({"font.family": "Times New Roman", "mathtext.fontset": "custom", "mathtext.rm": "Times New Roman",
                     "mathtext.it": "Times New Roman:italic", "mathtext.bf": "Times New Roman:bold", "font.size": 9.5,
                     "axes.facecolor": "#fbfbfa", "axes.linewidth": 0.8, "xtick.major.width": 0.8, "ytick.major.width": 0.8,
                     "legend.handlelength": 1.6, "axes.titleweight": "bold", "axes.titlesize": 9.5, "axes.labelsize": 9,
                     "axes.edgecolor": C["ink2"], "axes.labelcolor": C["ink"], "xtick.color": C["ink2"],
                     "ytick.color": C["ink2"], "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": C["grid"], "grid.linewidth": 0.6, "legend.frameon": False,
                     "lines.linewidth": 1.8, "savefig.dpi": 400, "figure.dpi": 120})
OUT = "fig/"

import matplotlib.dates as mdates
def fmt_dates(ax, short=False):
    if short:
        ax.xaxis.set_major_locator(mdates.MonthLocator(bymonth=(1, 7)))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%b\n%Y"))
    else:
        ax.xaxis.set_major_locator(mdates.YearLocator()); ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
def dates(yyyymm): return pd.to_datetime([f"{int(x)//100}-{int(x)%100:02d}-15" for x in yyyymm])
def panel(ax, lab): ax.text(-0.11, 1.04, lab, transform=ax.transAxes, fontweight="bold", fontsize=10, va="bottom")
def save(fig, name): fig.savefig(OUT + name, bbox_inches="tight"); plt.close(fig)

di, dc = prep.india(), prep.china()
raw = pd.read_csv("data/india_vahan_monthly.csv")
R = json.load(open("results/summary.json"))

# ---------- Figure 1: framework schematic ----------
def fig1():
    fig, ax = plt.subplots(figsize=(7.4, 3.6)); ax.set_axis_off(); ax.set_xlim(0, 10); ax.set_ylim(0, 4.6)
    boxes = [(0.1, 2.6, "(a) Registration data\nEV and total sales\nchoice share $s_t$\ninstalled base $x_t$\npolicy path $S_t$"),
             (2.6, 2.6, "(b) Payoff library $\\Theta$\ninstalled base terms\nphase-specific subsidy\ngain and loss terms\ncalendar terms"),
             (5.1, 2.6, "(c) Joint estimation\nsmooth baseline $a_t$\n(penalty $\\kappa$)\nsparse, sign-constrained\ncoefficients $\\beta$"),
             (7.6, 2.6, "(d) Learned dynamics\n$u_t = a_t + \\Theta_t^{\\top}\\beta$\n$s_t = \\sigma(u_t)$\n$x_t = x_{t-1}$\n$\\quad + r_t(s_t - x_{t-1})$"),
             (2.6, 0.25, "(e) Baseline forecasts\nlast value, local trend,\nrandom forest,\nnetwork-linear;\nvalidation-weighted"),
             (5.1, 0.25, "(f) Forecasts\niterate the dynamics\nwith the known policy\ncalendar; conformal\nintervals"),
             (7.6, 0.25, "(g) Policy analysis\ncounterfactual paths\ncost per additional EV\nsubsidy-independence\nmargin")]
    cols = [C["blue"], C["aqua"], C["violet"], C["orange"], C["aqua"], C["violet"], C["orange"]]
    for (x, y, t), c in zip(boxes, cols):
        ax.add_patch(FancyBboxPatch((x, y), 2.25, 1.75, boxstyle="round,pad=0.02,rounding_size=0.12",
                                    fc=c + "1f", ec=c, lw=1.2))
        ax.text(x + 1.125, y + 0.875, t, ha="center", va="center", fontsize=7.0, color=C["ink"], linespacing=1.35)
    def arr(x0, y0, x1, y1): ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=10, color=C["ink2"], lw=1))
    arr(2.35, 3.47, 2.6, 3.47); arr(4.85, 3.47, 5.1, 3.47); arr(7.35, 3.47, 7.6, 3.47)
    arr(6.22, 2.6, 3.73, 2.0); arr(4.85, 1.12, 5.1, 1.12); arr(7.35, 1.12, 7.6, 1.12); arr(8.72, 2.6, 8.72, 2.0)
    save(fig, "fig1_framework.png")

# ---------- Figure 2: data and policy ----------
def fig2():
    fig, axs = plt.subplots(3, 2, figsize=(7.2, 6.6), gridspec_kw=dict(height_ratios=[2.2, 1, 1.6]))
    t = dates(di.yyyymm)
    ax = axs[0, 0]; ax.plot(t, 100 * di.s, color=C["blue"], label="Monthly electric share")
    ax.plot(t, 100 * di.xlag, color=C["orange"], label="Installed-base share $x_{t-1}$")
    for m in (202305, 202403, 202503):
        ax.axvspan(dates([m])[0] - pd.Timedelta(days=14), dates([m])[0] + pd.Timedelta(days=14), color=C["yellow"], alpha=0.25, lw=0)
    ax.set_ylabel("Share of two-wheeler\nregistrations (%)"); ax.legend(loc="upper left", fontsize=7.5); ax.set_title("India, electric two-wheelers"); panel(ax, "a")
    ax = axs[1, 0]; ax.step(t, di.S, where="mid", color=C["violet"]); ax.set_ylabel("Central incentive\n(% of price)"); panel(ax, "c")
    for x, y, lab in ((202108, 39.5, "FAME-II raised"), (202307, 20.5, "FAME-II cut"), (202405, 9.3, "EMPS, then\nPM E-DRIVE"), (202410, 0.8, "halved")):
        ax.text(dates([x])[0], y, lab, fontsize=6.5, color=C["ink2"], va="bottom", linespacing=1.0)
    ax.set_ylim(0, 47)
    tc = dates(dc.yyyymm)
    ax = axs[0, 1]; ax.plot(tc, 100 * dc.s, color=C["blue"], label="Monthly NEV retail share")
    ax.plot(tc, 100 * dc.xlag, color=C["orange"], label="Installed-base share $x_{t-1}$")
    ax.axvspan(dates([202512])[0] - pd.Timedelta(days=14), dates([202512])[0] + pd.Timedelta(days=14), color=C["yellow"], alpha=0.25, lw=0)
    ax.set_ylabel("Share of passenger-car\nretail sales (%)"); ax.legend(loc="upper left", fontsize=7.5); ax.set_title("China, new energy passenger vehicles"); panel(ax, "b")
    ax = axs[1, 1]; ax.step(tc, dc.S, where="mid", color=C["violet"]); ax.set_ylabel("Purchase-tax saving\n(% of price)"); ax.set_ylim(0, 12); panel(ax, "d")
    ax.annotate("exemption halved\n1 Jan 2026", (dates([202601])[0], 5), xytext=(-70, 12), textcoords="offset points", fontsize=6.5, color=C["ink2"])
    ax = axs[2, 0]
    ax.plot(dates(raw.yyyymm), 100 * raw.lmv_ev / raw.lmv_total, color=C["aqua"], label="Electric cars (no central demand incentive)")
    ax.set_ylabel("Electric share of car\nregistrations (%)"); ax.legend(loc="upper left", fontsize=7.5); panel(ax, "e")
    ax = axs[2, 1]
    ax.plot(dates(raw.yyyymm), 100 * raw.w3_ev / raw.w3_total, color=C["magenta"], label="Electric three-wheelers, India")
    ax.set_ylabel("Electric share of three-\nwheeler registrations (%)"); ax.legend(loc="upper left", fontsize=7.5); panel(ax, "f")
    for a in (axs[0, 0], axs[1, 0], axs[2, 0], axs[2, 1]): fmt_dates(a)
    for a in (axs[0, 1], axs[1, 1]): fmt_dates(a, short=True)
    xl = (dates([201901])[0], dates([202508])[0]); 
    for a in (axs[0, 0], axs[1, 0], axs[2, 0], axs[2, 1]): a.set_xlim(*xl)
    for a in (axs[0, 0], axs[0, 1]): a.tick_params(labelbottom=False)
    fig.tight_layout(); save(fig, "fig2_data_policy.png")

# ---------- Figure 3: learned decomposition ----------
def fig3():
    D = pd.read_csv("results/india_decomposition.csv"); Dc = pd.read_csv("results/china_decomposition.csv")
    ci = R["india_coef"]; cc = R["china_coef"]
    fig, axs = plt.subplots(2, 2, figsize=(7.2, 5.4))
    t = dates(D.yyyymm); ax = axs[0, 0]
    ax.plot(t, 100 * D.s, color=C["ink2"], lw=1.2, marker="o", ms=2.5, label="Observed")
    ax.plot(t, 100 * D.fit, color=C["blue"], label="Learned model")
    ax.set_ylabel("Electric share (%)"); ax.legend(fontsize=7.5); ax.set_title("India: learning fit"); panel(ax, "a")
    ax = axs[1, 0]
    lib = fw.library(di, [k for k in ci]);
    ax.fill_between(t, D.a_lo, D.a_hi, color=C["blue"], alpha=0.15, lw=0)
    ax.plot(t, D.a, color=C["blue"], label="Baseline payoff $a_t$ (90% band)")
    ax.plot(t, D.a + lib["L"] * ci["L"], color=C["orange"], lw=1.2, label="$a_t$ + loss response")
    ax.plot(t, D.a + D.policy + D.calendar, color=C["ink2"], lw=0.9, ls=":", label="Full payoff $u_t$")
    ax.set_ylabel("Payoff gap (logit units)"); ax.legend(fontsize=7, loc="lower right"); ax.set_title("India: payoff decomposition"); panel(ax, "c")
    tc = dates(Dc.yyyymm); ax = axs[0, 1]
    ax.plot(tc, 100 * Dc.s, color=C["ink2"], lw=1.2, marker="o", ms=2.5, label="Observed")
    ax.plot(tc, 100 * Dc.fit, color=C["blue"], label="Learned model")
    ax.set_ylabel("NEV share (%)"); ax.legend(fontsize=7.5); ax.set_title("China: learning fit"); panel(ax, "b")
    ax = axs[1, 1]; libc = fw.library(dc, [k for k in cc])
    ax.fill_between(tc, Dc.a_lo, Dc.a_hi, color=C["blue"], alpha=0.15, lw=0)
    ax.plot(tc, Dc.a, color=C["blue"], label="Baseline payoff $a_t$ (90% band)")
    ax.plot(tc, Dc.a + libc["L"] * cc["L"], color=C["orange"], lw=1.2, label="$a_t$ + loss response")
    ax.set_ylabel("Payoff gap (logit units)"); ax.legend(fontsize=7, loc="lower right"); ax.set_title("China: payoff decomposition"); panel(ax, "d")
    for a in (axs[0, 0], axs[1, 0]): fmt_dates(a)
    for a in (axs[0, 1], axs[1, 1]): fmt_dates(a, short=True)
    fig.tight_layout(); save(fig, "fig3_decomposition.png")

# ---------- Figure 4: identification profile ----------
def fig4():
    P = pd.read_csv("results/kappa_profile.csv")
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.6))
    for ax, mk, lab in ((axs[0], "India e-2W", "a"), (axs[1], "China NEV", "b")):
        q = P[P.market == mk]
        for term, col, nm in (("L", C["orange"], "loss response $\\beta_L$"), ("S1", C["blue"], "nascent-phase subsidy $\\beta_{S1}$"),
                              ("S2", C["aqua"], "mature-phase subsidy $\\beta_{S2}$")):
            ax.plot(q.kappa, q[term], marker="o", ms=3.5, color=col, label=nm)
        ax.set_xscale("log"); ax.set_xlabel("Smoothness penalty $\\kappa$"); ax.set_title(mk); panel(ax, lab)
        ax.set_ylabel("Coefficient (logit per % of price)")
    axs[0].legend(fontsize=6.8, loc="upper center")
    cv = pd.read_csv("results/cv_kappa.csv")
    ax = axs[2]
    for mk, col in (("India e-2W", C["blue"]), ("China NEV", C["orange"])):
        q = cv[cv.market == mk]; ax.plot(q.kappa, q.cv_mae_pp / q.cv_mae_pp.min(), marker="o", ms=3.5, color=col, label=mk)
    ax.set_xscale("log"); ax.set_xlabel("Smoothness penalty $\\kappa$"); ax.set_ylabel("Blocked CV error / minimum"); ax.legend(fontsize=7); ax.set_title("Selection of $\\kappa$"); panel(ax, "c")
    fig.tight_layout(); save(fig, "fig4_identification.png")

# ---------- Figure 5: forecast accuracy ----------
ORDER = ["Proposed (combined smooth TV)", "Proposed, single selected configuration", "Two-stage window TV", "Fixed coefficients",
         "GBM", "SARIMAX", "MLP", "Logistic trend", "Persistence"]
LAB = {"Proposed (combined smooth TV)": "Proposed (combined)", "Proposed, single selected configuration": "Proposed (single config.)",
       "Two-stage window TV": "Two-stage window TV", "Fixed coefficients": "Fixed coefficients"}
def fig5():
    F = pd.read_csv("results/forecasts.csv"); F["ae"] = (F.pred - F.obs).abs() * 100
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 3.0), gridspec_kw=dict(width_ratios=[1.25, 1.25, 1]))
    for ax, mk, lab in ((axs[0], "India e-2W", "a"), (axs[1], "China NEV", "b")):
        m = F[F.market == mk].groupby("model").ae.mean().reindex(ORDER)
        cols = [C["blue"] if k.startswith("Proposed") else (C["violet"] if k in ("Two-stage window TV", "Fixed coefficients") else C["ink2"]) for k in m.index]
        ax.barh(range(len(m)), m.values, color=cols, height=0.62)
        for i, v in enumerate(m.values): ax.text(v, i, f" {v:.2f}", va="center", fontsize=6.8, color=C["ink"])
        ax.set_yticks(range(len(m))); ax.set_yticklabels([LAB.get(k, k) for k in m.index] if lab == "a" else []); ax.invert_yaxis()
        ax.set_xlabel("MAE (percentage points)"); ax.set_title(mk); panel(ax, lab); ax.grid(axis="y", visible=False)
        ax.set_xlim(0, m.max() * 1.25)
    ax = axs[2]
    for mk, col in (("India e-2W", C["blue"]), ("China NEV", C["orange"])):
        for mod, ls in (("Proposed (combined smooth TV)", "-"), ("GBM", "--")):
            q = F[(F.market == mk) & (F.model == mod)].groupby("h").ae.mean()
            ax.plot(q.index, q.values, ls=ls, marker="o", ms=3.5, color=col, label=f"{mk.split()[0]}, {'proposed' if ls == '-' else 'GBM'}")
    ax.set_xticks([1, 2, 3]); ax.set_xlabel("Horizon (months)"); ax.set_ylabel("MAE (pp)"); ax.legend(fontsize=6.3, loc="upper center", bbox_to_anchor=(0.5, -0.28), ncol=2); ax.set_title("Error by horizon"); panel(ax, "c")
    fig.tight_layout(); save(fig, "fig5_forecast_accuracy.png")

# ---------- Figure 6: forecast trajectories with intervals ----------
def fig6():
    F = pd.read_csv("results/forecasts.csv"); I = pd.read_csv("results/intervals.csv")
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.8))
    for ax, mk, d, lab in ((axs[0], "India e-2W", di, "a"), (axs[1], "China NEV", dc, "b")):
        dd = d[d.yyyymm >= (202307 if lab == "a" else 202501)]
        ax.plot(dates(dd.yyyymm), 100 * dd.s, color=C["ink2"], marker="o", ms=2.5, lw=1.0, label="Observed")
        q = I[I.market == mk]
        for k, (f, g) in enumerate(q.groupby("fold")):
            tt = dates(g.yyyymm)
            ax.fill_between(tt, 100 * g.lo, 100 * g.hi, color=C["blue"], alpha=0.16, lw=0, label="80% conformal interval" if k == 0 else None)
            ax.plot(tt, 100 * g.pred, color=C["blue"], marker="s", ms=3, label="Proposed forecast" if k == 0 else None)
            gb = F[(F.market == mk) & (F.model == "GBM") & (F.fold == f)]
            ax.plot(dates(gb.yyyymm), 100 * gb.pred, color=C["orange"], lw=1.0, ls="--", label="GBM" if k == 0 else None)
        ax.set_ylabel("Share (%)"); ax.set_title(mk + ", three-month forecasts by fold"); ax.legend(fontsize=6.8, loc="upper left"); panel(ax, lab); fmt_dates(ax, short=True)
    fig.tight_layout(); save(fig, "fig6_forecast_paths.png")

# ---------- Figure 7: error damping (Corollary 1) ----------
def fig7():
    F = pd.read_csv("results/forecasts.csv"); F = F[F.model == "Proposed (combined smooth TV)"].copy()
    lg = lambda p: np.log(p / (1 - p))
    F["eu"] = np.abs(lg(F.pred) - lg(F.obs)); F["es"] = np.abs(F.pred - F.obs)
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.8))
    ax = axs[0]
    for mk, col in (("India e-2W", C["blue"]), ("China NEV", C["orange"])):
        q = F[F.market == mk]; ax.scatter(q.eu, 100 * q.es, s=18, color=col, label=mk, edgecolor="white", lw=0.5)
    e = np.linspace(0, F.eu.max() * 1.05, 50)
    ax.plot(e, 100 * e / 4, color=C["ink2"], lw=1, ls="--", label="Bound $|u-\\hat u|/4$ (Prop. 1)")
    ax.set_xlabel("Absolute payoff (logit) error"); ax.set_ylabel("Absolute share error (pp)"); ax.legend(fontsize=6.8); panel(ax, "a")
    ax = axs[1]; s = np.linspace(0.005, 0.995, 200); ax.plot(100 * s, s * (1 - s), color=C["violet"])
    for mk, col, d in (("India", C["blue"], di), ("China", C["orange"], dc)):
        m = d.s.values[-12:].mean(); ax.scatter([100 * m], [m * (1 - m)], color=col, s=30, zorder=3)
        ax.annotate(f"{mk}, last 12 months", (100 * m, m * (1 - m)), xytext=(6, -12), textcoords="offset points", fontsize=7, color=C["ink"])
    ax.set_xlabel("Electric share $s$ (%)"); ax.set_ylabel("Damping factor $s(1-s)$"); ax.set_title("Payoff-to-share sensitivity"); panel(ax, "b")
    fig.tight_layout(); save(fig, "fig7_error_damping.png")

# ---------- Figure 8: subsidy-independence margin ----------
def fig8():
    P = pd.read_csv("results/review_margin_paths.csv")
    cols = {1.0: C["magenta"], 10.0: C["blue"], 100.0: C["violet"], 1000.0: C["aqua"]}
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.9))
    for ax, mk, lab in ((axs[0], "India e-2W", "a"), (axs[1], "China NEV", "b")):
        g = P[P.market == mk]; env = g.groupby("yyyymm").agg(lo=("lo", "min"), hi=("hi", "max")).reset_index(); t = dates(env.yyyymm)
        ax.fill_between(t, env.lo, env.hi, color=C["ink2"], alpha=0.13, lw=0, label="90% bands, all $\\kappa$")
        for k, col in cols.items():
            h = g[g.kappa == k]; ax.plot(dates(h.yyyymm), h.m, color=col, lw=1.2, label=f"$\\kappa$ = {k:g}")
        ax.axhline(0, color=C["ink"], lw=0.8)
        ax.set_ylabel("$m_t$ (logit units)"); ax.set_title(mk, loc="left"); panel(ax, lab); fmt_dates(ax, short=(lab == "b"))
    axs[0].legend(fontsize=6.6, loc="lower right", ncol=1)
    fig.tight_layout(); save(fig, "fig8_independence_margin.png")

# ---------- Figure 9: counterfactual policy paths ----------
def fig9():
    cf = R["counterfactual"]; names = ["Actual path", "Maintain May 2023 level", "Linear taper to zero by June 2025", "Abrupt withdrawal in June 2023"]
    cols = [C["ink2"], C["blue"], C["aqua"], C["orange"]]
    fig, axs = plt.subplots(2, 2, figsize=(7.2, 5.0))
    P10 = pd.read_csv("results/counterfactual_paths_k10.csv"); P1000 = pd.read_csv("results/counterfactual_paths_k1000.csv"); t = dates(P10.yyyymm)
    ax = axs[0, 0]
    for n, c in zip(names, cols): ax.step(t, P10[n + " S"], where="mid", color=c, label=n)
    ax.set_ylabel("Incentive (% of price)"); ax.set_ylim(-1, 58); ax.legend(fontsize=6.0, loc="upper center", ncol=2, columnspacing=0.8, handlelength=1.4); ax.set_title("Policy paths, June 2023 to June 2025"); panel(ax, "a"); fmt_dates(ax, short=True)
    ax = axs[0, 1]
    for n, c in zip(names, cols):
        ax.plot(t, 100 * P10[n], color=c, lw=1.4); ax.plot(t, 100 * P1000[n], color=c, lw=1.0, ls="--")
    ax.plot(dates(di.yyyymm[di.yyyymm >= 202306]), 100 * di.s[di.yyyymm >= 202306], color=C["ink"], lw=0, marker="o", ms=2.2)
    ax.set_ylabel("Simulated electric share (%)"); ax.set_title("Simulated adoption under each path", pad=4); panel(ax, "b"); fmt_dates(ax, short=True)
    ax.text(0.02, 0.97, "solid: $\\kappa$=10 (CV-selected)\ndashed: $\\kappa$=1000 (rigid baseline)\ndots: observed", transform=ax.transAxes, va="top", fontsize=6.3, color=C["ink2"])
    ax = axs[1, 0]; ks = ["kappa=10", "kappa=100", "kappa=1000"]; w = 0.26
    for j, (n, c) in enumerate(zip(names[:3], cols[:3])):
        vals = [cf[k][n]["additional_ev_vs_withdrawal"] / 1e5 for k in ks]
        ax.bar(np.arange(3) + (j - 1) * w, vals, width=w - 0.03, color=c, label=n)
    ax.axhline(0, color=C["ink2"], lw=0.8); ax.set_xticks(range(3)); ax.set_xticklabels(["$\\kappa$=10", "$\\kappa$=100", "$\\kappa$=1000"])
    ax.set_ylabel("Additional EVs vs withdrawal (lakh)"); ax.legend(fontsize=6.3); panel(ax, "c")
    ax = axs[1, 1]
    for j, (n, c) in enumerate(zip(names[:3], cols[:3])):
        vals = [cf[k][n]["outlay_per_additional_ev_rs"] for k in ks]
        vals = [np.nan if v is None else v / 1e5 for v in vals]
        ax.bar(np.arange(3) + (j - 1) * w, vals, width=w - 0.03, color=c)
        for i, v in enumerate(vals):
            ax.text(i + (j - 1) * w, (0 if np.isnan(v) else v), " n/a" if np.isnan(v) else f"{v:.2f}", ha="center", va="bottom", fontsize=6.2, rotation=90)
    ax.set_xticks(range(3)); ax.set_xticklabels(["$\\kappa$=10", "$\\kappa$=100", "$\\kappa$=1000"]); ax.set_ylabel("Outlay per additional\nEV (Rs lakh)"); panel(ax, "d")
    fig.tight_layout(); save(fig, "fig9_counterfactuals.png")

# ---------- Figure 10: robustness and placebo ----------
def fig10():
    Rb = pd.read_csv("results/robustness.csv"); Pl = pd.read_csv("results/placebo_cars.csv", index_col=0); Ci = pd.read_csv("results/india_coefficients.csv", index_col=0)
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.9))
    ax = axs[0]; terms = ["L", "pre", "march", "fest", "covid", "S1", "S2"]
    ax.boxplot([Rb[t] for t in terms], orientation="horizontal", widths=0.55, patch_artist=True,
               boxprops=dict(facecolor=C["blue"] + "33", edgecolor=C["blue"]), medianprops=dict(color=C["blue"]),
               whiskerprops=dict(color=C["ink2"]), capprops=dict(color=C["ink2"]), flierprops=dict(marker="o", ms=2.5, mec=C["ink2"]))
    ax.set_yticks(range(1, len(terms) + 1)); ax.set_yticklabels(["loss $L$", "announcement", "March", "festive", "COVID", "subsidy $S1$", "subsidy $S2$"])
    ax.axvline(0, color=C["ink2"], lw=0.8); ax.set_xlabel("Coefficient across 81 specifications"); ax.set_title("India: specification robustness"); panel(ax, "a")
    ax = axs[1]; terms2 = ["S1", "S2", "G", "L", "pre", "march", "covid"]
    y = np.arange(len(terms2))
    for off, T, col, nm in ((-0.15, Ci, C["blue"], "Electric two-wheelers (treated)"), (0.15, Pl, C["orange"], "Electric cars (placebo)")):
        e = T.reindex(terms2)
        ax.errorbar(e.estimate, y + off, xerr=[e.estimate - e.lo, e.hi - e.estimate], fmt="o", ms=4, color=col, ecolor=col, elinewidth=1, capsize=2, label=nm)
    ax.set_yticks(y); ax.set_yticklabels(["subsidy $S1$", "subsidy $S2$", "gain $G$", "loss $L$", "announcement", "March", "COVID"]); ax.invert_yaxis()
    ax.axvline(0, color=C["ink2"], lw=0.8); ax.set_xlabel("Coefficient (90% bootstrap interval)"); ax.legend(fontsize=6.4, loc="upper center", bbox_to_anchor=(0.45, -0.2), ncol=2); ax.set_title("Placebo test"); panel(ax, "b")
    fig.tight_layout(); save(fig, "fig10_robustness_placebo.png")

if __name__ == "__main__":
    which = sys.argv[1:] or ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    for w in which: globals()["fig" + w](); print("fig", w)
