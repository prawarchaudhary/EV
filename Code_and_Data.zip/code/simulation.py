"""Simulation study: recovery of known payoff structures from synthetic India-like series.

Two ground truths are taken from the India fits: (A) transient loss response (kappa = 10 fit) and
(B) persistent phase-specific subsidy effect (kappa = 1000 fit). Synthetic logit shares are generated
as y_t = a_t + z_t' beta + e_t with Gaussian noise of standard deviation sigma in {0.5, 1, 2} times the
residual standard deviation of the India fit. Each of 100 replicates is estimated with (i) the proposed
sign-constrained smooth estimator with kappa chosen by blocked cross-validation, (ii) the same estimator
without sign constraints and (iii) the two-stage window estimator (w = 6)."""
import sys, json
import numpy as np, pandas as pd
from scipy.optimize import lsq_linear
sys.path.insert(0, "code")
import prep, framework as fw
TERMS = ["x", "x2", "S1", "S2", "G", "L", "pre", "fest", "march", "covid"]
KGRID = [3.0, 10.0, 100.0, 1000.0]
rng = np.random.default_rng(7)
d0 = prep.india(); lib = fw.library(d0, TERMS); t = [c for c in TERMS if lib[c].std() > 0]
Z = lib[t].values; T = len(d0); D = np.diff(np.eye(T), 2, axis=0)

def solve(y, kappa, w=None, constrained=True, tau=0.02, lam=1e-3):
    w = np.ones(T) if w is None else w; W = np.diag(w); sd = Z.std(0); act = np.ones(len(t), bool)
    for _ in range(30):
        Za = Z[:, act]; p = Za.shape[1]; names = np.array(t)[act]
        A = np.vstack([np.c_[W, W @ Za], np.c_[np.sqrt(kappa) * D, np.zeros((T - 2, p))], np.c_[np.zeros((p, T)), np.sqrt(lam) * np.eye(p)]])
        lb = np.r_[np.full(T, -np.inf), [0.0 if (constrained and n in fw.NONNEG) else -np.inf for n in names]]
        sol = lsq_linear(A, np.r_[W @ y, np.zeros(T - 2 + p)], bounds=(lb, np.full(T + p, np.inf)), method="bvls").x
        b = np.zeros(len(t)); b[act] = sol[T:]; a = sol[:T]
        small = act & (np.abs(b * sd) < tau)
        if not small.any(): return a, b
        act &= ~small
    return a, b

def cv_kappa(y, constrained=True, L=6):
    best, bk = np.inf, None
    for k in KGRID:
        err = []
        for s0 in range(2, T - 2, L):
            w = np.ones(T); w[s0:s0 + L] = 0; a, b = solve(y, k, w, constrained)
            err.extend(np.abs(fw.sigma(a + Z @ b)[s0:s0 + L] - fw.sigma(y[s0:s0 + L])))
        if np.mean(err) < best: best, bk = np.mean(err), k
    return bk

def block_two_stage(y, wlen=6):
    dd = d0.copy(); dd["y"] = y
    a, b = fw.fit_block(dd, t, window=wlen, tau=0.02)
    return a, b.reindex(t).values

truth = {}
for name, kap in (("A: transient loss response", 10.0), ("B: persistent phase-specific subsidy", 1000.0)):
    a, b = fw.fit_smooth(d0, t, kappa=kap, tau=0.02)
    truth[name] = (a, b.reindex(t).values)
a_ref, b_ref = truth["A: transient loss response"]
res_sd = float(np.std(d0.y.values - a_ref - Z @ b_ref))
rows, store = [], []
for name, (a_true, b_true) in truth.items():
    for mult in (0.5, 1.0, 2.0):
        sig = mult * res_sd
        for r in range(100):
            y = a_true + Z @ b_true + rng.normal(0, sig, T)
            k = cv_kappa(y)
            for est, (ah, bh) in (("Proposed (constrained, CV kappa)", solve(y, k)),
                                  ("Unconstrained smooth (same kappa)", solve(y, k, constrained=False)),
                                  ("Two-stage window (w = 6)", block_two_stage(y))):
                row = dict(scenario=name, noise_mult=mult, sigma=sig, rep=r, estimator=est, kappa=k,
                           base_rmse=float(np.sqrt(np.mean((ah - a_true) ** 2))),
                           share_mae_pp=float(100 * np.mean(np.abs(fw.sigma(ah + Z @ bh) - fw.sigma(a_true + Z @ b_true)))))
                row.update({f"b_{c}": float(v) for c, v in zip(t, bh)}); rows.append(row)
        print(name, mult, "done", flush=True)
R = pd.DataFrame(rows); R.to_csv("results/simulation_runs.csv", index=False)
json.dump(dict(residual_sd=res_sd, terms=t, truth={k: dict(zip(t, map(float, v[1]))) for k, v in truth.items()}),
          open("results/simulation_truth.json", "w"), indent=1)
summ = []
for (sc, m, est), g in R.groupby(["scenario", "noise_mult", "estimator"]):
    bt = dict(zip(t, truth[sc][1]))
    for c in t:
        v = g[f"b_{c}"].values; tv = bt[c]
        summ.append(dict(scenario=sc, noise_mult=m, estimator=est, term=c, true=tv, mean=v.mean(), bias=v.mean() - tv,
                         rmse=float(np.sqrt(np.mean((v - tv) ** 2))),
                         selection_rate=float(np.mean(v != 0)), wrong_sign_rate=float(np.mean(np.sign(v) * np.sign(tv) < 0)) if tv != 0 else float(np.mean(v != 0)),
                         base_rmse=g.base_rmse.mean(), share_mae_pp=g.share_mae_pp.mean(), kappa_median=g.kappa.median()))
pd.DataFrame(summ).to_csv("results/simulation_summary.csv", index=False)
print(pd.DataFrame(summ).query("term in ['L','S1','pre']").round(4).to_string())
