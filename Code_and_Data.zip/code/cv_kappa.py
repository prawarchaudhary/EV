"""Blocked cross-validation of the smoothness penalty kappa: contiguous blocks (3 months India,
2 months China) are removed from the data-fidelity term and predicted by the fitted model."""
import sys; sys.path.insert(0, "code")
import numpy as np, pandas as pd, prep, framework as fw
from scipy.optimize import lsq_linear
TERMS = ["x", "x2", "S1", "S2", "G", "L", "pre", "fest", "march", "covid"]
def fit_w(d, t, kappa, wts, lam=1e-3):
    n = len(d); y = d.y.values; Z = fw.library(d, t).values; p = Z.shape[1]; D = np.diff(np.eye(n), 2, axis=0); W = np.diag(wts)
    A = np.vstack([np.c_[W, W @ Z], np.c_[np.sqrt(kappa) * D, np.zeros((n - 2, p))], np.c_[np.zeros((p, n)), np.sqrt(lam) * np.eye(p)]])
    lb = np.r_[np.full(n, -np.inf), [0 if q in fw.NONNEG else -np.inf for q in t]]
    sol = lsq_linear(A, np.r_[W @ y, np.zeros(n - 2 + p)], bounds=(lb, np.full(n + p, np.inf)), method="bvls").x
    return sol[:n], sol[n:]
rows = []
for nm, d, L in (("India e-2W", prep.india(), 3), ("China NEV", prep.china(), 2)):
    lib = fw.library(d, TERMS); t = [x for x in TERMS if lib[x].std() > 0]; n = len(d)
    for k in (1.0, 3.0, 10.0, 30.0, 100.0, 300.0, 1000.0):
        err = []
        for s0 in range(2, n - 2, L):
            w = np.ones(n); w[s0:s0 + L] = 0; a, b = fit_w(d, t, k, w)
            err.extend(np.abs(fw.sigma(a + lib[t].values @ b)[s0:s0 + L] - d.s.values[s0:s0 + L]))
        rows.append(dict(market=nm, kappa=k, cv_mae_pp=100 * float(np.mean(err))))
pd.DataFrame(rows).to_csv("results/cv_kappa.csv", index=False); print(pd.DataFrame(rows))
