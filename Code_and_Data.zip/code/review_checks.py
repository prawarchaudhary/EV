"""Additional analyses requested in the internal review: (1) Diebold-Mariano tests of forecast accuracy,
(2) the subsidy-independence margin across the smoothness bracket, (3) effective degrees of freedom of the
learned models, (4) residual-bootstrap intervals that allow for 12-month dependence. Writes results/review_*.csv."""
import sys, json, warnings
import numpy as np, pandas as pd
from scipy import stats
sys.path.insert(0, "code")
import prep, framework as fw
warnings.filterwarnings("ignore")
TERMS = ["x", "x2", "S1", "S2", "G", "L", "pre", "fest", "march", "covid"]; TAU = 0.02
rng = np.random.default_rng(11)
di, dc = prep.india(), prep.china()
def terms_for(d):
    lib = fw.library(d, TERMS); return [t for t in TERMS if lib[t].std() > 0]

# (1) Diebold-Mariano with the Harvey-Leybourne-Newbold correction, absolute-error loss, lag h-1 = 2
fo = pd.read_csv("results/forecasts.csv"); fo["ae"] = 100 * np.abs(fo.pred - fo.obs); rows = []
for mk, g in fo.groupby("market"):
    base = g[g.model == "Proposed (combined smooth TV)"].sort_values("yyyymm").set_index("yyyymm").ae
    for m in g.model.unique():
        if m.startswith("Proposed (combined") or "oracle" in m: continue
        comp = g[g.model == m].sort_values("yyyymm").set_index("yyyymm").ae.reindex(base.index)
        dd = (base - comp).values; n = len(dd); h = 3; dbar = dd.mean(); dc0 = dd - dbar
        gam = [np.sum(dc0[k:] * dc0[:n - k]) / n for k in range(h)]
        var = (gam[0] + 2 * sum(gam[1:])) / n
        if var <= 0: var = gam[0] / n
        dm = dbar / np.sqrt(var); k = np.sqrt((n + 1 - 2 * h + h * (h - 1) / n) / n); hln = dm * k
        p = 2 * stats.t.sf(abs(hln), n - 1)
        wil = stats.wilcoxon(dd).pvalue if np.any(dd != 0) else 1.0
        rows.append(dict(market=mk, comparator=m, n=n, mae_proposed=base.mean(), mae_comparator=comp.mean(),
                         mean_diff=dbar, hln_stat=hln, p_hln=p, p_wilcoxon=wil, share_proposed_better=float(np.mean(dd < 0))))
pd.DataFrame(rows).to_csv("results/review_dm_tests.csv", index=False)

# (2) margin across kappa with block bootstrap (B = 300 at each kappa)
def fit(d, kappa):
    t = terms_for(d); a, b = fw.fit_smooth(d, t, kappa=kappa, tau=TAU); return a, b, a + fw.library(d, t).values @ b.values, t
def margin(d, a, b, t):
    net = sum(b[c] * fw.library(d, [c])[c].values for c in ("x", "x2") if c in t and b[c] != 0) if any(c in t for c in ("x", "x2")) else 0.0
    return a + net - np.log(d.xlag.values / (1 - d.xlag.values))
def boot(d, kappa, B=300, L=3):
    a, b, u, t = fit(d, kappa); e = d.y.values - u; T = len(d); ms = []
    for _ in range(B):
        idx = []
        while len(idx) < T:
            s0 = rng.integers(0, T - L + 1); idx.extend(range(s0, s0 + L))
        dd = d.copy(); dd["y"] = u + e[np.array(idx[:T])]
        a2, b2 = fw.fit_smooth(dd, t, kappa=kappa, tau=TAU); ms.append(margin(dd, a2, b2, t))
    return margin(d, a, b, t), np.array(ms)
mrows, mpaths = [], []
for lab, d in (("India e-2W", di), ("China NEV", dc)):
    for kap in (1.0, 10.0, 100.0, 1000.0):
        m, ms = boot(d, kap); lo, hi = np.quantile(ms, 0.05, 0), np.quantile(ms, 0.95, 0)
        pos = np.where(lo > 0)[0]
        mrows.append(dict(market=lab, kappa=kap, margin_last=m[-1], lo_last=lo[-1], hi_last=hi[-1],
                          first_robust_positive=int(d.yyyymm.values[pos[0]]) if len(pos) else None,
                          positive_all_after=bool(len(pos) and np.all(lo[pos[0]:] > 0)), mean_margin_last12=float(m[-12:].mean())))
        mpaths.append(pd.DataFrame(dict(market=lab, kappa=kap, yyyymm=d.yyyymm.values, m=m, lo=lo, hi=hi)))
pd.DataFrame(mrows).to_csv("results/review_margin_kappa.csv", index=False); pd.concat(mpaths).to_csv("results/review_margin_paths.csv", index=False)

# (3) effective degrees of freedom: trace of the hat matrix of the final (active-set) linear smoother
def edf_smooth(d, kappa, lam=1e-3):
    t = terms_for(d); a, b = fw.fit_smooth(d, t, kappa=kappa, tau=TAU); act = [c for c in t if b[c] != 0]
    T = len(d); Z = fw.library(d, act).values; X = np.c_[np.eye(T), Z]; D = np.diff(np.eye(T), 2, axis=0)
    P = np.zeros((T + len(act),) * 2); P[:T, :T] = kappa * D.T @ D; P[T:, T:] = lam * np.eye(len(act))
    H = X @ np.linalg.solve(X.T @ X + P, X.T); return float(np.trace(H)), len(act)
erows = []
for lab, d, k in (("India e-2W", di, 10.0), ("China NEV", dc, 1.0)):
    for kap in sorted({k, 1.0, 10.0, 100.0, 1000.0}):
        e, p = edf_smooth(d, kap); erows.append(dict(market=lab, model=f"Smooth baseline, kappa = {kap:g}", edf=e, active_terms=p, T=len(d)))
    for w in (6, 12):
        a, b = fw.fit_block(d, terms_for(d), window=w, tau=TAU); nwin = int(np.ceil(len(d) / w))
        erows.append(dict(market=lab, model=f"Two-stage window, w = {w}", edf=nwin + int((b != 0).sum()), active_terms=int((b != 0).sum()), T=len(d)))
pd.DataFrame(erows).to_csv("results/review_edf.csv", index=False)

# (4) India coefficient intervals with 12-month blocks (allows for the seasonal residual dependence)
a, b, u, t = fit(di, 10.0); e = di.y.values - u; T = len(di); out = []
for L in (3, 6, 12):
    bb = []
    for _ in range(300):
        idx = []
        while len(idx) < T:
            s0 = rng.integers(0, T - L + 1); idx.extend(range(s0, s0 + L))
        dd = di.copy(); dd["y"] = u + e[np.array(idx[:T])]; _, b2 = fw.fit_smooth(dd, t, kappa=10.0, tau=TAU); bb.append(b2.reindex(t).values)
    bb = np.array(bb)
    for j, c in enumerate(t):
        out.append(dict(block=L, term=c, estimate=b[c], lo=np.quantile(bb[:, j], 0.05), hi=np.quantile(bb[:, j], 0.95), selected=(bb[:, j] != 0).mean()))
pd.DataFrame(out).to_csv("results/review_block_length.csv", index=False)
pd.set_option("display.width", 200)
print(pd.read_csv("results/review_dm_tests.csv").round(3).to_string()); print(pd.read_csv("results/review_margin_kappa.csv").round(3).to_string())
print(pd.read_csv("results/review_edf.csv").round(2).to_string()); print(pd.read_csv("results/review_block_length.csv").query("term in ['L','pre','fest','march','covid','S1','S2']").round(4).to_string())
