#!/bin/sh
set -e
cd "$(dirname "$0")/.."
python3 code/table_widths.py manuscript.md build_manuscript.md
pandoc build_manuscript.md -o manuscript_raw.docx --reference-doc=ref.docx --resource-path=.
python3 code/postprocess_docx.py manuscript_raw.docx manuscript_post.docx
python3 code/fix_styles.py manuscript_post.docx Manuscript_DualCarbon_LogitDynamics.docx
python3 code/table_widths.py supplement.md build_supplement.md
pandoc build_supplement.md -o supplement_raw.docx --reference-doc=ref.docx --resource-path=.
python3 code/postprocess_docx.py supplement_raw.docx supplement_post.docx 7.5
python3 code/fix_styles.py supplement_post.docx Supplementary_Material_DualCarbon_LogitDynamics.docx
