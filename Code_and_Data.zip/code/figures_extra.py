"""New schematic, evaluation-design figure, simulation figures and supplementary figures."""
import sys, json
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
sys.path.insert(0, "code")
import figures as F            # applies the common style (Times New Roman) and helpers
import prep, framework as fw
from evaluate import TERMS
C, dates, panel, save, fmt_dates = F.C, F.dates, F.panel, F.save, F.fmt_dates
di, dc = prep.india(), prep.china()
R = json.load(open("results/summary.json"))

def box(fig, x, y, w, h, col, label, title):
    ax = fig.add_axes([x, y, w, h]); ax.set_axis_off()
    ax.add_patch(FancyBboxPatch((0.005, 0.005), 0.99, 0.99, boxstyle="round,pad=0,rounding_size=0.03",
                                transform=ax.transAxes, fc=col + "14", ec=col, lw=1.1))
    ax.text(0.03, 0.965, label, transform=ax.transAxes, fontweight="bold", fontsize=10.5, va="top")
    ax.text(0.12, 0.965, title, transform=ax.transAxes, fontsize=8.6, va="top", color=C["ink"])
    return ax

def mini(fig, rect):
    ax = fig.add_axes(rect); ax.tick_params(labelsize=6.5, length=2, pad=1); ax.grid(True, lw=0.4)
    return ax

def arrow(fig, p0, p1, rad=0.0):
    fig.add_artist(FancyArrowPatch(p0, p1, transform=fig.transFigure, arrowstyle="-|>", mutation_scale=11,
                                   color=C["ink2"], lw=1.1, connectionstyle=f"arc3,rad={rad}"))

# ---------------- Figure 1: schematic with real data panels ----------------
def fig_schematic():
    fig = plt.figure(figsize=(7.4, 5.6))
    t = dates(di.yyyymm)
    # (a) data
    box(fig, 0.005, 0.53, 0.235, 0.45, C["blue"], "a", "Registration and\npolicy data")
    ax = mini(fig, [0.05, 0.76, 0.17, 0.12]); ax.plot(t, 100 * di.s, color=C["blue"], lw=1); ax.plot(t, 100 * di.xlag, color=C["orange"], lw=1)
    ax.set_ylabel("share (%)", fontsize=6.5); ax.set_xticks([]); ax.text(0.03, 0.8, "$s_t$", color=C["blue"], transform=ax.transAxes, fontsize=8)
    ax.text(0.03, 0.08, "$x_t$", color=C["orange"], transform=ax.transAxes, fontsize=8)
    ax = mini(fig, [0.05, 0.58, 0.17, 0.12]); ax.step(t, di.S, where="mid", color=C["violet"], lw=1)
    ax.set_ylabel("$S_t$ (%)", fontsize=6.5); fmt_dates(ax); ax.tick_params(axis="x", labelsize=5.5, rotation=0)
    for lab in ax.get_xticklabels()[::2]: lab.set_visible(False)
    # (b) library and sparse coefficients
    box(fig, 0.255, 0.53, 0.255, 0.45, C["aqua"], "b", "Candidate library $\\Theta$ and\nsparse coefficients $\\beta$")
    terms = [c for c in TERMS if fw.library(di, TERMS)[c].std() > 0]
    Lb = fw.library(di, terms); coef = R["india_coef"]
    lab = {"x": "$x$", "x2": "$x^2$", "S1": "$S^{(1)}$", "S2": "$S^{(2)}$", "G": "$G$", "L": "$L$", "pre": "pre", "fest": "fest", "march": "Mar", "covid": "cov"}
    n = len(terms); x0, y0, wcol, hcol = 0.282, 0.6, 0.0165, 0.27
    for j, c in enumerate(terms):
        on = coef[c] != 0
        ax = fig.add_axes([x0 + j * (wcol + 0.0015), y0, wcol, hcol]); v = Lb[c].values
        ax.set_facecolor((C["blue"] + "22") if on else "#ececec"); ax.plot(v, np.arange(len(v))[::-1], color=C["blue"] if on else "#9a9a9a", lw=0.7)
        ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
        for sp in ax.spines.values(): sp.set_visible(True); sp.set_color(C["blue"] if on else "#bbbbbb"); sp.set_linewidth(0.8)
        ax.set_xlabel(lab[c], fontsize=6.3, rotation=90, labelpad=2)
    fig.text(x0 - 0.004, y0 + hcol / 2, "time $\\downarrow$", rotation=90, fontsize=6.5, va="center", ha="right")
    ax2 = fig.add_axes([0.453, y0, 0.032, hcol]); sd = Lb.std().values
    vals = np.array([abs(coef[c]) * s for c, s in zip(terms, sd)])
    ax2.barh(range(n), vals, color=[C["blue"] if coef[c] != 0 else C["grid"] for c in terms], height=0.7)
    ax2.set_yticks(range(n)); ax2.set_yticklabels([lab[c] for c in terms], fontsize=5.6); ax2.invert_yaxis(); ax2.yaxis.tick_right()
    ax2.set_xticks([]); ax2.grid(False); ax2.set_title("std. $|\\beta|$", fontsize=6.8, fontweight="normal", pad=2)
    for sp in ("top", "left", "bottom"): ax2.spines[sp].set_visible(False)
    fig.text(0.38, 0.548, "blue: retained terms; grey: removed by thresholding", fontsize=6.2, ha="center", color=C["ink2"])
    # (c) joint estimation
    box(fig, 0.525, 0.53, 0.235, 0.45, C["violet"], "c", "Joint estimation: smooth\nbaseline + policy jumps")
    D = pd.read_csv("results/india_decomposition.csv"); m = D.yyyymm >= 202201; td = dates(D.yyyymm[m])
    ax = mini(fig, [0.565, 0.6, 0.18, 0.27])
    ax.plot(td, np.log(D.s[m] / (1 - D.s[m])), "o", ms=2, color=C["ink2"], label="$y_t$")
    ax.plot(td, D.a[m], color=C["blue"], lw=1.4, label="$a_t$ (smooth)")
    ax.plot(td, (D.a + D.policy + D.calendar)[m], color=C["orange"], lw=0.9, label="$a_t+\\Theta_t^\\top\\beta$")
    ax.legend(fontsize=5.6, loc="lower right", handlelength=1.2); fmt_dates(ax); ax.tick_params(axis="x", labelsize=5.5)
    ax.set_title("logit share $y_t$", fontsize=6.5, fontweight="normal", pad=2, loc="left")
    # (d) logit dynamics
    box(fig, 0.775, 0.53, 0.22, 0.45, C["orange"], "d", "Logit dynamics\n(bounded rationality)")
    fig.text(0.885, 0.835, "$u_t = a_t + \\Theta_t^{\\top}\\beta$\n$s_t = \\sigma(u_t)$\n$x_t = x_{t-1} + r_t\\,(s_t - x_{t-1})$",
             ha="center", va="center", fontsize=8.4, linespacing=1.8)
    ax = mini(fig, [0.81, 0.585, 0.16, 0.13]); uu = np.linspace(-6, 6, 200); ax.plot(uu, fw.sigma(uu), color=C["orange"], lw=1.3)
    ax.set_xlabel("payoff gap $u$", fontsize=6.3, labelpad=1); ax.set_ylabel("$\\sigma(u)$", fontsize=6.5)
    ax.text(0.03, 0.78, "noisy best\nresponse", transform=ax.transAxes, fontsize=5.8, color=C["ink2"])
    # (e) baseline forecasters and weights
    box(fig, 0.13, 0.03, 0.27, 0.44, C["aqua"], "e", "Baseline forecasters and\nvalidation weights")
    t0 = int(np.where(di.yyyymm == 202410)[0][0]); d_tr = di.iloc[:t0]
    ax = mini(fig, [0.165, 0.09, 0.15, 0.27])
    m0 = fw.TVPayoffModel([c for c in TERMS if fw.library(d_tr, TERMS)[c].std() > 0], kappa=10.0, a_model="last").fit(d_tr)
    th = dates(d_tr.yyyymm[-18:]); ax.plot(th, m0.a[-18:], color=C["ink2"], lw=1.2)
    fut = dates(di.yyyymm[t0 - 1:t0 + 3]); cols = {"last": C["blue"], "trend": C["orange"], "rf": C["aqua"], "netlin": C["violet"]}
    for am, col in cols.items():
        mm = fw.TVPayoffModel(m0.terms, kappa=10.0, a_model=am).fit(d_tr)
        S_all = np.r_[d_tr.S.values, di.S.values[t0:t0 + 3]]; since = fw.months_since_change(S_all)
        path = [mm.a[-1]]; E, M = d_tr.E.values[-1], d_tr.M.values[-1]
        for h in range(3):
            row = di.iloc[[t0 + h]]
            Fh = np.c_[[E / M], since[t0 + h], row.S.values]
            path.append(mm.a_forecast(h + 1, Fh, E / M))
        ax.plot(fut, path, color=col, lw=1.1, label=am)
    ax.legend(fontsize=5.4, loc="lower center", ncol=4, handlelength=0.9, columnspacing=0.6, bbox_to_anchor=(0.62, 1.0), frameon=False)
    fmt_dates(ax, short=True); ax.tick_params(axis="x", labelsize=5.2)
    ax.set_ylabel("$a_t$", fontsize=7)
    FC = pd.read_csv("results/fold_configs.csv"); q = FC[(FC.market == "India e-2W") & (FC.fold == 202410)]
    wg = q.groupby("baseline_forecaster").weight.sum().reindex(["last", "trend", "rf", "netlin"])
    ax2 = mini(fig, [0.335, 0.11, 0.05, 0.22]); ax2.bar(range(4), wg.values, color=[cols[k] for k in wg.index], width=0.7)
    ax2.set_xticks([]); ax2.set_title("weight", fontsize=6.5, fontweight="normal", pad=2); ax2.tick_params(labelsize=5)
    # (f) forecasts with intervals
    box(fig, 0.42, 0.03, 0.27, 0.44, C["violet"], "f", "Combined forecast and\nconformal interval")
    I = pd.read_csv("results/intervals.csv"); g = I[(I.market == "India e-2W")]
    ax = mini(fig, [0.46, 0.09, 0.21, 0.27]); dd = di[di.yyyymm >= 202307]
    ax.plot(dates(dd.yyyymm), 100 * dd.s, "o-", ms=2, lw=0.8, color=C["ink2"])
    for k, (f, gg) in enumerate(g.groupby("fold")):
        tt = dates(gg.yyyymm); ax.fill_between(tt, 100 * gg.lo, 100 * gg.hi, color=C["blue"], alpha=0.18, lw=0); ax.plot(tt, 100 * gg.pred, color=C["blue"], lw=1.2)
    fmt_dates(ax, short=True); ax.tick_params(axis="x", labelsize=5.2); ax.set_ylabel("share (%)", fontsize=6.5)
    # (g) policy analysis
    box(fig, 0.71, 0.03, 0.285, 0.44, C["orange"], "g", "Policy analysis")
    Mg = pd.read_csv("results/india_margin.csv"); ax = mini(fig, [0.745, 0.25, 0.23, 0.12])
    ax.fill_between(dates(Mg.yyyymm), Mg.lo, Mg.hi, color=C["aqua"], alpha=0.25, lw=0); ax.plot(dates(Mg.yyyymm), Mg.m, color=C["aqua"], lw=1.2)
    ax.axhline(0, color=C["ink2"], lw=0.6); ax.set_xticks([]); ax.set_ylabel("$m_t$", fontsize=7)
    ax.set_title("subsidy-independence margin (90% band)", fontsize=6.3, fontweight="normal", pad=2)
    ax = mini(fig, [0.745, 0.075, 0.23, 0.12]); cf = R["counterfactual"]
    nm = ["Actual path", "Maintain May 2023 level", "Linear taper to zero by June 2025"]; ks = ["kappa=10", "kappa=1000"]
    for j, k in enumerate(ks):
        ax.bar(np.arange(3) + (j - 0.5) * 0.36, [cf[k][n]["outlay_per_additional_ev_rs"] / 1e5 if cf[k][n]["outlay_per_additional_ev_rs"] else 0 for n in nm],
               width=0.34, color=[C["blue"], C["orange"]][j], label=["$\\kappa$=10", "$\\kappa$=1000"][j])
    ax.set_xticks(range(3)); ax.set_xticklabels(["actual", "maintain", "taper"], fontsize=5.8); ax.set_ylabel("Rs lakh / EV", fontsize=6); ax.set_title("outlay per additional EV", fontsize=6.3, fontweight="normal", pad=2)
    ax.legend(fontsize=5.4, handlelength=1, loc="upper right")
    # arrows
    arrow(fig, (0.240, 0.755), (0.255, 0.755)); arrow(fig, (0.510, 0.755), (0.525, 0.755)); arrow(fig, (0.760, 0.755), (0.775, 0.755))
    arrow(fig, (0.64, 0.53), (0.30, 0.47), rad=-0.15); arrow(fig, (0.40, 0.25), (0.42, 0.25)); arrow(fig, (0.69, 0.25), (0.71, 0.25))
    arrow(fig, (0.885, 0.53), (0.885, 0.47))
    save(fig, "fig1_framework.png")

# ---------------- Evaluation design (train / validation / test) ----------------
def fig_design():
    fig, axs = plt.subplots(2, 1, figsize=(7.2, 3.6), gridspec_kw=dict(height_ratios=[6, 4]))
    for ax, d, folds, mk, lab in ((axs[0], di, (202401, 202404, 202407, 202410, 202501, 202504), "India e-2W", "a"),
                                  (axs[1], dc, (202509, 202512, 202603, 202606), "China NEV", "b")):
        tt = dates(d.yyyymm); w = pd.Timedelta(days=30)
        for i, f in enumerate(folds):
            t0 = int(np.where(d.yyyymm == f)[0][0]); vorig = [v for v in range(t0 - 9, t0, 3) if v >= 12]
            ax.barh(i, tt[vorig[0]] - tt[0], left=tt[0], color=C["ink2"], alpha=0.55, height=0.62, label="Training" if i == 0 else None)
            for k, v in enumerate(vorig):
                ax.barh(i, 3 * w, left=tt[v], color=C["blue"], alpha=0.35 + 0.2 * k, height=0.62, edgecolor="white", lw=0.6,
                        label="Validation folds (3 months each)" if (i == 0 and k == 0) else None)
            ax.barh(i, 3 * w, left=tt[t0], color=C["yellow"], height=0.62, edgecolor="white", lw=0.6, label="Test fold (3 months)" if i == 0 else None)
        ax.set_yticks(range(len(folds))); ax.set_yticklabels([f"fold {i + 1}" for i in range(len(folds))], fontsize=8); ax.invert_yaxis()
        fmt_dates(ax, short=(lab == "b")); ax.set_title(mk, loc="left", fontsize=9.5); panel(ax, lab); ax.grid(axis="y", visible=False)
        if lab == "a": ax.legend(fontsize=7.2, loc="lower left", ncol=3, bbox_to_anchor=(0, 1.08), frameon=False)
    fig.tight_layout(); save(fig, "fig_design.png")

if __name__ == "__main__":
    which = sys.argv[1:] or ["schematic", "design"]
    for w in which: globals()["fig_" + w](); print(w)
