"""Data preparation: adoption shares, fleet (installed-base) shares and policy covariates.

India e-2W policy timeline (central demand incentive), representative vehicle with a
3 kWh battery and an ex-factory price of Rs 1.20 lakh:
  2019-04..2021-06-10  FAME-II  Rs 10,000/kWh, cap 20% of ex-factory price   -> Rs 24,000
  2021-06-11..2023-05  FAME-II  Rs 15,000/kWh, cap 40%                        -> Rs 45,000
  2023-06..2024-03     FAME-II  Rs 10,000/kWh, cap 15%                        -> Rs 18,000
  2024-04..2024-09     EMPS     Rs 5,000/kWh, cap Rs 10,000                   -> Rs 10,000
  2024-10..2025-03     PM E-DRIVE Rs 5,000/kWh, cap Rs 10,000                 -> Rs 10,000
  2025-04..            PM E-DRIVE Rs 2,500/kWh, cap Rs 5,000                  -> Rs  5,000
China: NEV purchase tax 10%; full exemption to 2025-12, half exemption from 2026-01.
"""
import numpy as np, pandas as pd

def india_subsidy(yyyymm, kwh=3.0, price=120000.0):
    y, m = divmod(int(yyyymm), 100)
    t = y * 100 + m
    def fame(rate, cap): return min(rate * kwh, cap * price)
    if t < 201904:
        return np.nan
    if t < 202106:
        return fame(10000, 0.20)
    if t == 202106:  # 10 days old regime, 20 days new regime
        return (10 * fame(10000, 0.20) + 20 * fame(15000, 0.40)) / 30
    if t < 202306:
        return fame(15000, 0.40)
    if t < 202404:
        return fame(10000, 0.15)
    if t < 202504:
        return min(5000 * kwh, 10000, 0.15 * price)
    return min(2500 * kwh, 5000, 0.15 * price)

INDIA_PRECUT = {202305, 202403, 202503}   # month before an announced reduction takes effect
INDIA_COVID = {202004, 202005, 202104, 202105}
CHINA_PRECUT = {202512}

def logit(s): return np.log(s / (1 - s))

def reference(S, k=6):
    """Reference subsidy: trailing mean of the previous k months (excluding current)."""
    R = pd.Series(S).shift(1).rolling(k, min_periods=1).mean().to_numpy().copy()
    R[0] = S[0]
    return R

def india(segment="tw", kwh=3.0, price=120000.0, k_ref=6):
    d = pd.read_csv("data/india_vahan_monthly.csv")
    tot, ev = f"{segment}_total", f"{segment}_ev"
    if segment == "lmv":
        tot, ev = "lmv_total", "lmv_ev"
    if segment == "w3":
        tot, ev = "w3_total", "w3_ev"
    d = d.rename(columns={tot: "n", ev: "e"})[["yyyymm", "n", "e"]].copy()
    d["s"] = d.e / d.n
    d["M"] = d.n.cumsum(); d["E"] = d.e.cumsum()
    d["x"] = d.E / d.M                      # adopter share among buyers since 2019-01
    d["xlag"] = d.x.shift(1)
    d["r"] = d.n / d.M                      # revision rate n_t / M_t
    d["y"] = logit(d.s)
    d["S"] = [100 * india_subsidy(t, kwh, price) / price for t in d.yyyymm]   # % of ex-factory price
    d = d[d.yyyymm >= 201904].reset_index(drop=True)
    d["R"] = reference(d.S.values, k_ref)
    d["G"] = np.maximum(d.S - d.R, 0.0)     # gain relative to reference
    d["L"] = np.minimum(d.S - d.R, 0.0)     # loss relative to reference (<= 0)
    mm = d.yyyymm % 100
    d["pre"] = d.yyyymm.isin(INDIA_PRECUT).astype(float)
    d["fest"] = mm.isin([10, 11]).astype(float)
    d["march"] = (mm == 3).astype(float)
    d["covid"] = d.yyyymm.isin(INDIA_COVID).astype(float)
    d["t"] = np.arange(len(d), dtype=float)
    d["xm"] = 0.05          # phase anchor: marginal subsidy effect interpolates between x=0 and x=5%
    return d

def china(k_ref=6):
    d = pd.read_csv("data/china_cpca_monthly.csv").rename(columns={"pv": "n", "nev": "e"})
    d["s"] = d.e / d.n
    d["M"] = d.n.cumsum(); d["E"] = d.e.cumsum()
    d["x"] = d.E / d.M
    d["xlag"] = d.x.shift(1)
    d["r"] = d.n / d.M
    d["y"] = logit(d.s)
    d["xlag"] = d.xlag.fillna(d.x.iloc[0])
    d["S"] = np.where(d.yyyymm >= 202601, 5.0, 10.0)   # tax saving, % of price (10% tax; full vs half exemption)
    d["R"] = reference(d.S.values, k_ref)
    d["G"] = np.maximum(d.S - d.R, 0.0)
    d["L"] = np.minimum(d.S - d.R, 0.0)
    mm = d.yyyymm % 100
    d["pre"] = d.yyyymm.isin(CHINA_PRECUT).astype(float)
    d["fest"] = mm.isin([1, 2]).astype(float)          # Spring Festival months
    d["march"] = 0.0
    d["covid"] = 0.0
    d["t"] = np.arange(len(d), dtype=float)
    d["xm"] = 1.0
    return d

if __name__ == "__main__":
    di = india(); print(di[["yyyymm", "s", "x", "S", "R", "G", "L", "pre"]].round(4).to_string())
    dc = china(); print(dc[["yyyymm", "s", "x", "S", "L", "pre"]].round(4).to_string())
