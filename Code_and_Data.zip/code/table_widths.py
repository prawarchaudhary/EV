"""Rewrite pipe-table separator rows so that pandoc column widths are proportional to content length."""
import re, sys
def vis(c):
    c = re.sub(r"\\(mathrm|boldsymbol|hat|bar)\{([^}]*)\}", r"\2", c)
    c = re.sub(r"\\[a-zA-Z]+", "x", c); c = re.sub(r"[{}$^_*]", "", c)
    return len(c.strip())
lines = open(sys.argv[1]).read().split("\n"); out = []; i = 0
while i < len(lines):
    if lines[i].startswith("|") and i + 1 < len(lines) and re.match(r"^\|(\s*:?-+:?\s*\|)+\s*$", lines[i + 1]):
        j = i
        while j < len(lines) and lines[j].startswith("|"): j += 1
        block = lines[i:j]; cells = [[c for c in r.strip().strip("|").split("|")] for r in block]
        seps = cells[1]; rows = [cells[0]] + cells[2:]
        body = rows[1:] or rows; w = [max(min(max(vis(r[k]) for r in body if k < len(r)), 40), 4) for k in range(len(seps))]
        hw = [max([vis(x) for x in rows[0][k].split()] + [4]) for k in range(len(seps))]
        w = [max(a, b) + 4 for a, b in zip(w, hw)]
        new = []
        for s, n in zip(seps, w):
            s = s.strip(); l, r = s.startswith(":"), s.endswith(":")
            new.append((":" if l else "") + "-" * n + (":" if r else ""))
        block[1] = "|" + "|".join(new) + "|"; out += block; i = j
    else:
        out.append(lines[i]); i += 1
open(sys.argv[2], "w").write("\n".join(out))
