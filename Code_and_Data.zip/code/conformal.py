"""Sequential split-conformal intervals for the combined forecast. Calibration set for test fold k:
absolute logit errors of the combined forecast on its validation folds plus all errors of the
combined forecast on test folds 1..k-1 (known by the time fold k is forecast). Level 80%."""
import json, numpy as np, pandas as pd
F = pd.read_csv("results/forecasts.csv"); S = json.load(open("results/forecast_selection.json"))
lg = lambda p: np.log(np.clip(p, 1e-6, 1 - 1e-6) / (1 - np.clip(p, 1e-6, 1 - 1e-6)))
rows, ALPHA = [], 0.2
for mk, key in (("India e-2W", "india"), ("China NEV", "china")):
    P = F[(F.market == mk) & (F.model == "Proposed (combined smooth TV)")]
    past = []
    for info in S[key]:
        f = info["fold"]; g = P[P.fold == f]
        cal = np.abs(np.array(info["verr"]).ravel()).tolist() + past
        n = len(cal); k = int(np.ceil((n + 1) * (1 - ALPHA)))
        q = np.sort(cal)[min(k, n) - 1]
        for _, r in g.iterrows():
            rows.append(dict(market=mk, fold=f, yyyymm=r.yyyymm, h=r.h, obs=r.obs, pred=r.pred, n_cal=n, q=q,
                             lo=1 / (1 + np.exp(-(lg(r.pred) - q))), hi=1 / (1 + np.exp(-(lg(r.pred) + q)))))
        past += np.abs(lg(g.obs.values) - lg(g.pred.values)).tolist()
I = pd.DataFrame(rows); I["covered"] = (I.obs >= I.lo) & (I.obs <= I.hi)
I.to_csv("results/intervals.csv", index=False)
print(I.groupby("market").agg(coverage=("covered", "mean"), width_pp=("hi", lambda x: 0)).assign(
    width_pp=I.assign(w=100 * (I.hi - I.lo)).groupby("market").w.mean()))
print(I[["market", "fold", "n_cal", "q", "covered"]].drop_duplicates(["market", "fold"]).to_string())
