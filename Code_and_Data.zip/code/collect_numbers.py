"""Collect every number quoted in the manuscript from results files."""
import json, numpy as np, pandas as pd
R = json.load(open("results/summary.json"))
N = {}
F = pd.read_csv("results/forecasts.csv"); F["ae"] = (F.pred - F.obs).abs() * 100
mae = F.groupby(["market", "model"]).ae.mean().unstack(0)
N["forecast_mae"] = mae.round(3).to_dict()
N["forecast_mae_h"] = F[F.model.isin(["Proposed (combined smooth TV)", "GBM"])].groupby(["market", "model", "h"]).ae.mean().round(2).to_dict()
N["forecast_mae_h"] = {f"{a}|{b}|{c}": v for (a, b, c), v in N["forecast_mae_h"].items()}
F2 = F.copy(); F2["mean_obs"] = F2.groupby("market").obs.transform("mean") * 100
N["mean_test_share"] = F2.groupby("market").mean_obs.mean().round(2).to_dict()
I = pd.read_csv("results/intervals.csv")
N["coverage"] = I.groupby("market").covered.mean().round(3).to_dict()
N["interval_width_pp"] = I.assign(w=100 * (I.hi - I.lo)).groupby("market").w.mean().round(2).to_dict()
N["learning_mae"] = pd.read_csv("results/learning_mae.csv", index_col=0).round(3).to_dict()
for k in ("india_coefficients", "china_coefficients", "placebo_cars"):
    N[k] = pd.read_csv(f"results/{k}.csv", index_col=0).round(4).to_dict(orient="index")
rb = pd.read_csv("results/robustness.csv")
N["robust"] = {t: dict(min=round(rb[t].min(), 4), max=round(rb[t].max(), 4), median=round(rb[t].median(), 4),
                        share_nonzero=round(float((rb[t] != 0).mean()), 3)) for t in ["S1", "S2", "G", "L", "pre", "fest", "march", "covid", "x", "x2"]}
N["n_spec"] = len(rb)
N["kappa_profile"] = pd.read_csv("results/kappa_profile.csv").round(4).to_dict(orient="records")
N["cv_kappa"] = pd.read_csv("results/cv_kappa.csv").round(4).to_dict(orient="records")
N.update({k: R[k] for k in R if k not in ("counterfactual",)})
N["counterfactual"] = R["counterfactual"]
# logit error vs share error ratio by market (Corollary)
P = F[F.model == "Proposed (combined smooth TV)"].copy(); lg = lambda p: np.log(p / (1 - p))
P["eu"] = np.abs(lg(P.pred) - lg(P.obs)); P["es"] = np.abs(P.pred - P.obs)
N["logit_mae"] = P.groupby("market").eu.mean().round(3).to_dict()
N["share_over_logit"] = (P.groupby("market").es.mean() / P.groupby("market").eu.mean()).round(4).to_dict()
N["bound_holds_all"] = bool((P.es <= P.eu / 4 + 1e-12).all())
S = json.load(open("results/forecast_selection.json"))
W = pd.DataFrame([f["weights"] for f in S["india"]]).mean().sort_values(ascending=False)
N["india_top_weights"] = W.head(4).round(3).to_dict()
Wc = pd.DataFrame([f["weights"] for f in S["china"]]).mean().sort_values(ascending=False)
N["china_top_weights"] = Wc.head(4).round(3).to_dict()
N["n_india"], N["n_china"] = 75, 32
json.dump(N, open("results/numbers.json", "w"), indent=1, default=float)
print(json.dumps({k: N[k] for k in ("forecast_mae", "coverage", "interval_width_pp", "learning_mae", "logit_mae", "share_over_logit", "bound_holds_all", "india_top_weights", "china_top_weights", "mean_test_share")}, indent=1))
print(json.dumps(N["robust"], indent=0))
