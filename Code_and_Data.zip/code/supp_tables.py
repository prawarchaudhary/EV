"""Supplementary tables and in-sample trajectories. Writes results/supp_*.csv; every number in the
supplement is read from these files."""
import sys, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "code")
import prep, framework as fw
warnings.filterwarnings("ignore")
TERMS = ["x", "x2", "S1", "S2", "G", "L", "pre", "fest", "march", "covid"]
TAU = 0.02
di, dc = prep.india(), prep.china()

def terms_for(d):
    lib = fw.library(d, TERMS); return [t for t in TERMS if lib[t].std() > 0]

# S-table: per-fold validation-selected versus oracle configuration
fc = pd.read_csv("results/fold_configs.csv"); fo = pd.read_csv("results/forecasts.csv")
rows = []
for (mk, fold), g in fc.groupby(["market", "fold"], sort=False):
    top = g.loc[g.weight.idxmax()]; orc = g.loc[g.test_mae_pp.idxmin()]; vbest = g.loc[g.val_mae_pp.idxmin()]
    comb = fo[(fo.market == mk) & (fo.fold == fold) & (fo.model == "Proposed (combined smooth TV)")]
    rows.append(dict(market=mk, fold=int(fold), val_kappa=vbest.kappa, val_forecaster=vbest.baseline_forecaster,
                     val_val_mae=vbest.val_mae_pp, val_test_mae=vbest.test_mae_pp,
                     oracle_kappa=orc.kappa, oracle_forecaster=orc.baseline_forecaster, oracle_test_mae=orc.test_mae_pp,
                     combined_test_mae=float(100 * np.mean(np.abs(comb.pred - comb.obs))), max_weight=g.weight.max()))
pd.DataFrame(rows).to_csv("results/supp_fold_selection.csv", index=False)

# S-table: conformal coverage and width by market and horizon
iv = pd.read_csv("results/intervals.csv"); iv["width_pp"] = 100 * (iv.hi - iv.lo)
iv.groupby(["market", "h"]).agg(n=("covered", "size"), coverage=("covered", "mean"), width_pp=("width_pp", "mean")
                                ).reset_index().to_csv("results/supp_coverage.csv", index=False)

# S-table: forecast MAE by model, market and horizon
fo["ae"] = 100 * np.abs(fo.pred - fo.obs)
fo.pivot_table(index="model", columns=["market", "h"], values="ae", aggfunc="mean").to_csv("results/supp_mae_by_h.csv")

# S-table: robustness grid summarised by factor level
rb = pd.read_csv("results/robustness.csv"); out = []
rb["vehicle"] = rb.kwh.map(lambda v: f"{v:g} kWh") + ", Rs " + (rb.price / 1e5).map(lambda v: f"{v:g}") + " lakh"
for fac in ("vehicle", "k_ref", "kappa", "tau"):
    for lev, g in rb.groupby(fac):
        out.append(dict(factor=fac, level=lev, n=len(g), L_median=g.L.median(), L_pos=(g.L > 0).mean(),
                        S1_median=g.S1.median(), S1_pos=(g.S1 > 0).mean(), pre_median=g.pre.median()))
pd.DataFrame(out).to_csv("results/supp_robustness_factor.csv", index=False)

# S-table: sensitivity to the phase anchor x_bar
anc = []
for xm in (0.03, 0.05, 0.08, 0.10):
    for kap in (10.0, 1000.0):
        d = di.copy(); d["xm"] = xm; t = terms_for(d)
        a, b = fw.fit_smooth(d, t, kappa=kap, tau=TAU); u = a + fw.library(d, t).values @ b.values
        r = dict(x_bar=xm, kappa=kap, mae_pp=float(100 * np.mean(np.abs(fw.sigma(u) - d.s))))
        r.update({c: float(b.get(c, 0.0)) for c in TERMS}); anc.append(r)
pd.DataFrame(anc).to_csv("results/supp_anchor.csv", index=False)

# in-sample trajectories by learning approach (Figure S1)
traj = []
for lab, d, kk in (("India e-2W", di, 10.0), ("China NEV", dc, 1.0)):
    for name, cfg in {"Proposed smooth TV": dict(mode="smooth", kappa=kk), "Two-stage window TV (w = 6)": dict(mode="block", window=6),
                      "Fixed coefficients": dict(mode="fixed")}.items():
        m = fw.TVPayoffModel(terms_for(d), tau=TAU, **cfg).fit(d)
        traj.append(pd.DataFrame(dict(market=lab, model=name, yyyymm=d.yyyymm.values, obs=d.s.values, fit=np.asarray(m.in_sample()))))
pd.concat(traj).to_csv("results/supp_learning_paths.csv", index=False)

# simulation: spurious selection of subsidy terms when the truth has none (scenario A)
sr = pd.read_csv("results/simulation_runs.csv")
sr["subsidy_selected"] = (sr.b_S1 != 0) | (sr.b_S2 != 0)
sr.groupby(["scenario", "noise_mult", "estimator"]).agg(subsidy_selected=("subsidy_selected", "mean"),
    S1_mean=("b_S1", "mean"), S2_mean=("b_S2", "mean"), L_mean=("b_L", "mean"), base_rmse=("base_rmse", "mean"),
    share_mae_pp=("share_mae_pp", "mean"), kappa_median=("kappa", "median")).reset_index().to_csv("results/supp_simulation_overview.csv", index=False)
print(pd.read_csv("results/supp_fold_selection.csv").round(3).to_string())
print(pd.read_csv("results/supp_coverage.csv").round(3).to_string())
print(pd.read_csv("results/supp_anchor.csv").round(4).to_string())
print(pd.read_csv("results/supp_simulation_overview.csv").round(3).to_string())
