"""Final rolling-origin evaluation.

Proposed forecast: inverse-validation-MAE weighted combination of all smooth-TV configurations
(kappa in {3,10,30,100} x baseline-payoff forecaster in {last, trend, rf, netlin}); weights use the
three 3-month validation folds that precede each test fold. Prediction intervals: empirical 10th
and 90th percentiles of validation errors in logit space, by horizon, added to the combined
forecast (a split-conformal style construction). Also reported: single configuration selected
on validation, oracle configuration chosen on the test fold (post hoc), two-stage window TV
benchmark, fixed coefficients and five data-driven baselines.
"""
import sys, json, itertools, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "code")
import prep, framework as fw
from evaluate import run_model, BASELINES, mae, TERMS
warnings.filterwarnings("ignore")
H, NVAL = 3, 3
GRID = [dict(mode="smooth", kappa=k, a_model=a) for k, a in itertools.product([1.0, 3.0, 10.0, 30.0, 100.0],
                                                                              ["last", "trend", "rf", "netlin"])]
BGRID = [dict(mode="block", window=w, a_model="last") for w in (6, 9, 12)]

def lg(p): p = np.clip(p, 1e-6, 1 - 1e-6); return np.log(p / (1 - p))

def evaluate(d, test_starts, label, beta_prior=None):
    rows, info = [], []
    for t0 in test_starts:
        vorig = [v for v in range(t0 - NVAL * H, t0, H) if v >= 12]
        d_tr, d_te = d.iloc[:t0], d.iloc[t0:t0 + H]
        V = np.zeros((len(GRID), len(vorig))); VP = {}
        for i, c in enumerate(GRID):
            for j, v in enumerate(vorig):
                p = run_model(c, d.iloc[:v], d.iloc[v:v + H], beta_prior); VP[(i, j)] = p
                V[i, j] = mae(p, d.s.values[v:v + H])
        vs = V.mean(1); w = 1 / vs; w /= w.sum()
        P = np.array([run_model(c, d_tr, d_te, beta_prior) for c in GRID])
        comb = (P * w[:, None]).sum(0)
        # validation errors of the combination, logit space, by horizon
        verr = np.array([lg(d.s.values[v:v + H]) - lg(sum(w[i] * VP[(i, j)] for i in range(len(GRID))))
                         for j, v in enumerate(vorig)])          # (nval, H)
        # pool across horizons up to h to stabilise the small sample
        lo = np.array([np.quantile(verr[:, :h + 1], 0.10) for h in range(H)])
        hi = np.array([np.quantile(verr[:, :h + 1], 0.90) for h in range(H)])
        res = {"Proposed (combined smooth TV)": comb,
               "Proposed, single selected configuration": P[int(np.argmin(vs))],
               "Proposed, oracle configuration (post hoc)": P[int(np.argmin([mae(p, d_te.s) for p in P]))]}
        bv = [np.mean([mae(run_model(c, d.iloc[:v], d.iloc[v:v + H], beta_prior), d.s.values[v:v + H]) for v in vorig]) for c in BGRID]
        res["Two-stage window TV"] = run_model(BGRID[int(np.argmin(bv))], d_tr, d_te, beta_prior)
        res["Fixed coefficients"] = run_model(dict(mode="fixed"), d_tr, d_te, beta_prior)
        for k, f in BASELINES.items(): res[k] = f(d_tr, d_te)
        for k, p in res.items():
            for h in range(len(d_te)):
                r = dict(market=label, fold=int(d_te.yyyymm.values[0]), h=h + 1, model=k,
                         yyyymm=int(d_te.yyyymm.values[h]), obs=float(d_te.s.values[h]), pred=float(p[h]))
                if k.startswith("Proposed (combined"):
                    r["lo"] = float(fw.sigma(lg(p[h]) + lo[h])); r["hi"] = float(fw.sigma(lg(p[h]) + hi[h]))
                rows.append(r)
        info.append(dict(fold=int(d_te.yyyymm.values[0]), verr=verr.tolist(), weights={f"k{c['kappa']:g}-{c['a_model']}": float(x) for c, x in zip(GRID, w)},
                         single=GRID[int(np.argmin(vs))], block=BGRID[int(np.argmin(bv))]))
        print(label, d_te.yyyymm.values[0], "done", flush=True)
    return pd.DataFrame(rows), info

if __name__ == "__main__":
    di, dc = prep.india(), prep.china()
    ti = [int(np.where(di.yyyymm == m)[0][0]) for m in (202401, 202404, 202407, 202410, 202501, 202504)]
    tc = [int(np.where(dc.yyyymm == m)[0][0]) for m in (202509, 202512, 202603, 202606)]
    ri, ii = evaluate(di, ti, "India e-2W")
    rc, ic = evaluate(dc, tc, "China NEV")
    out = pd.concat([ri, rc]); out.to_csv("results/forecasts.csv", index=False)
    json.dump(dict(india=ii, china=ic), open("results/forecast_selection.json", "w"), indent=1, default=str)
    out["ae"] = (out.pred - out.obs).abs() * 100
    print(out.groupby(["market", "model"]).ae.mean().unstack(0).round(3).to_string())
