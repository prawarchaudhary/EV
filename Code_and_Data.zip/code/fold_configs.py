"""Per-fold validation and test errors of all 20 configurations (supplementary table, analogous to
the per-fold configuration tables of Chakraborty et al. 2026)."""
import sys, json, itertools
import numpy as np, pandas as pd
sys.path.insert(0, "code")
import prep
from evaluate import run_model, mae
H = 3
GRID = [dict(mode="smooth", kappa=k, a_model=a) for k, a in itertools.product([1.0, 3.0, 10.0, 30.0, 100.0], ["last", "trend", "rf", "netlin"])]
rows = []
for lab, d, months in (("India e-2W", prep.india(), (202401, 202404, 202407, 202410, 202501, 202504)),
                       ("China NEV", prep.china(), (202509, 202512, 202603, 202606))):
    for m in months:
        t0 = int(np.where(d.yyyymm == m)[0][0]); vorig = [v for v in range(t0 - 3 * H, t0, H) if v >= 12]
        for c in GRID:
            val = np.mean([mae(run_model(c, d.iloc[:v], d.iloc[v:v + H]), d.s.values[v:v + H]) for v in vorig])
            test = mae(run_model(c, d.iloc[:t0], d.iloc[t0:t0 + H]), d.s.values[t0:t0 + H])
            rows.append(dict(market=lab, fold=m, kappa=c["kappa"], baseline_forecaster=c["a_model"], val_mae_pp=100 * val, test_mae_pp=100 * test))
        print(lab, m, flush=True)
R = pd.DataFrame(rows)
R["weight"] = R.groupby(["market", "fold"]).val_mae_pp.transform(lambda v: (1 / v) / (1 / v).sum())
R.to_csv("results/fold_configs.csv", index=False)
