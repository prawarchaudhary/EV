"""Data-driven logit dynamics with time-varying payoff coefficients.

Choice (sales) share    s_t = sigma(u_t),   u_t = a_t + Theta(z_t) beta           (learned payoff gap)
Installed-base share    x_t = x_{t-1} + r_t (s_t - x_{t-1}),  r_t = n_t / M_t      (logit dynamic)

Two estimators of the time-varying part are implemented.
  mode="smooth"  (proposed)  a_t and beta estimated jointly; a_t penalised by kappa*||D2 a||^2,
                             beta made sparse by sequential thresholded ridge regression.
  mode="block"   (two-stage benchmark following Chakraborty, Wang & Ramazi 2026): beta from a
                             constant-coefficient STRR fit, then a_t piecewise constant on
                             windows of length w fitted to the residual.
Forecasting: the baseline payoff a_t is projected forward by a coefficient model selected on
validation folds, inserted into the learned payoff, and the logit dynamic is iterated.
"""
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from scipy.optimize import lsq_linear

def sigma(u): return 1.0 / (1.0 + np.exp(-u))

def library(d, terms):
    cols = {}
    for t in terms:
        if t == "x": cols[t] = d.xlag.values
        elif t == "x2": cols[t] = d.xlag.values ** 2
        elif t == "Sx": cols[t] = d.S.values * d.xlag.values
        elif t == "S1": cols[t] = d.S.values * (1 - d.xlag.values / d.xm.values)   # nascent-phase subsidy term
        elif t == "S2": cols[t] = d.S.values * (d.xlag.values / d.xm.values)       # mature-phase subsidy term
        else: cols[t] = d[t].values.astype(float)
    return pd.DataFrame(cols, index=d.index)

KEEP = set()   # terms exempt from thresholding (none by default)

def _thresh_loop(solve, Z, names, tau, maxit=30):
    sd = Z.std(0); sd[sd == 0] = 1.0
    act = np.ones(len(names), bool)
    for _ in range(maxit):
        beta = solve(act)
        small = act & (np.abs(beta * sd) < tau)
        small &= ~np.isin(names, list(KEEP))
        if not small.any(): return beta, act
        act &= ~small
    return beta, act

NONNEG = {"S", "S1", "S2", "G", "L"}   # theory-consistent signs: subsidies and gains cannot lower
                                        # the payoff, and a loss (L <= 0) cannot raise it

def fit_smooth(d, terms, kappa=10.0, lam=1e-3, tau=0.02):
    T = len(d); y = d.y.values; Z = library(d, terms).values
    D = np.diff(np.eye(T), 2, axis=0)
    def solve(act):
        Za = Z[:, act]; p = Za.shape[1]; names = np.array(terms)[act]
        A = np.vstack([np.c_[np.eye(T), Za], np.c_[np.sqrt(kappa) * D, np.zeros((T - 2, p))],
                       np.c_[np.zeros((p, T)), np.sqrt(lam) * np.eye(p)]])
        rhs = np.r_[y, np.zeros(T - 2), np.zeros(p)]
        lb = np.r_[np.full(T, -np.inf), [0.0 if n in NONNEG else -np.inf for n in names]]
        sol = lsq_linear(A, rhs, bounds=(lb, np.full(T + p, np.inf)), method="bvls").x
        b = np.zeros(len(terms)); b[act] = sol[T:]; solve.a = sol[:T]; return b
    beta, act = _thresh_loop(solve, Z, terms, tau)
    return solve.a.copy(), pd.Series(beta, index=terms)

def fit_block(d, terms, window=6, lam=1e-3, tau=0.02):
    T = len(d); y = d.y.values; Z = library(d, terms).values
    X1 = np.c_[np.ones(T), Z]
    def solve(act):
        A = X1[:, np.r_[True, act]]; names = np.array(terms)[act]; p = A.shape[1]
        Aa = np.vstack([A, np.c_[np.zeros((p - 1, 1)), np.sqrt(lam) * np.eye(p - 1)]])
        lb = np.r_[-np.inf, [0.0 if n in NONNEG else -np.inf for n in names]]
        w = lsq_linear(Aa, np.r_[y, np.zeros(p - 1)], bounds=(lb, np.full(p, np.inf)), method="bvls").x
        b = np.zeros(len(terms)); b[act] = w[1:]; return b
    beta, act = _thresh_loop(solve, Z, terms, tau)
    resid = y - Z @ beta
    a = np.zeros(T); ends = list(range(T, 0, -window))[::-1]
    starts = [0] + ends[:-1]
    for s0, e0 in zip(starts, ends): a[s0:e0] = resid[s0:e0].mean()
    return a, pd.Series(beta, index=terms)

def months_since_change(S):
    out, c = [], 0
    for i, v in enumerate(S):
        c = 0 if i > 0 and v != S[i - 1] else c + (i > 0)
        out.append(c)
    return np.array(out, float)

class TVPayoffModel:
    def __init__(self, terms, mode="smooth", kappa=10.0, window=6, tau=0.02,
                 a_model="last", k_trend=6, seed=0):
        self.terms, self.mode, self.kappa, self.window, self.tau = list(terms), mode, kappa, window, tau
        self.a_model, self.k_trend, self.seed = a_model, k_trend, seed

    def fit(self, d):
        self.d = d.reset_index(drop=True).copy()
        if self.mode == "smooth":
            self.a, self.beta = fit_smooth(self.d, self.terms, self.kappa, tau=self.tau)
        elif self.mode == "block":
            self.a, self.beta = fit_block(self.d, self.terms, self.window, tau=self.tau)
        elif self.mode == "fixed":     # constant-coefficient benchmark: a_t = constant
            a, b = fit_block(self.d, self.terms, window=len(self.d), tau=self.tau)
            self.a, self.beta = a, b
        if self.a_model == "rf":
            F = self._feat(self.d)
            self.rf = RandomForestRegressor(n_estimators=300, max_depth=5, min_samples_split=6,
                                            min_samples_leaf=3, random_state=self.seed).fit(F, self.a)
        if self.a_model == "netlin":   # baseline payoff linear in installed base (network effect)
            k = min(24, len(self.d)); X = self.d.xlag.values[-k:, None]
            self.nl = Ridge(alpha=1e-6).fit(X, self.a[-k:])
        return self

    def _feat(self, d):
        return np.c_[d.xlag.values, months_since_change(d.S.values), d.S.values]

    def payoff_fixed(self, d):
        return library(d, self.terms).values @ self.beta.values

    def in_sample(self):
        return sigma(self.a + self.payoff_fixed(self.d))

    def a_forecast(self, h, row_hist=None, xlag=None):
        if self.a_model == "last" or self.mode == "fixed":
            return self.a[-1]
        if self.a_model == "trend":
            k = self.k_trend; t = np.arange(k); slope = np.polyfit(t, self.a[-k:], 1)[0]
            return self.a[-1] + slope * h
        if self.a_model == "rf":
            return self.rf.predict(row_hist)[0]
        if self.a_model == "netlin":
            return self.nl.predict(np.array([[xlag]]))[0]

    def forecast(self, d_future, a_override=None):
        hist = self.d; fut = d_future.reset_index(drop=True).copy()
        M, E = hist.M.values[-1], hist.E.values[-1]
        S_all = np.r_[hist.S.values, fut.S.values]
        since_all = months_since_change(S_all)
        out = []
        for h in range(len(fut)):
            row = fut.iloc[[h]].copy(); row["xlag"] = E / M
            if a_override is not None: a_h = a_override[h]
            else:
                F = np.c_[row.xlag.values, since_all[len(hist) + h], row.S.values]
                a_h = self.a_forecast(h + 1, F, row.xlag.values[0])
            u = a_h + self.payoff_fixed(row)[0]
            s = sigma(u); out.append(s)
            M += row.n.values[0]; E += s * row.n.values[0]
        return np.array(out)
