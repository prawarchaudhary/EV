"""Structural estimates, uncertainty, robustness, placebo, counterfactual policy paths and the
subsidy-independence margin. All outputs are written to results/ and read by figures.py and the
manuscript builder, so that every number in the text comes from this file."""
import sys, json, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "code")
import prep, framework as fw
warnings.filterwarnings("ignore")
TERMS = ["x", "x2", "S1", "S2", "G", "L", "pre", "fest", "march", "covid"]
KAPPA_IN, KAPPA_CN, TAU, B = 10.0, 1.0, 0.02, 500   # kappa chosen by blocked cross-validation (cv_kappa.py)
KAPPA = KAPPA_IN
rng = np.random.default_rng(2026)
R = {}

def terms_for(d):
    lib = fw.library(d, TERMS); return [t for t in TERMS if lib[t].std() > 0]

def fit(d, kappa=KAPPA, tau=TAU):
    t = terms_for(d); a, b = fw.fit_smooth(d, t, kappa=kappa, tau=tau)
    u = a + fw.library(d, t).values @ b.values
    return a, b, u, t

def block_bootstrap(d, kappa=KAPPA, tau=TAU, B=B, L=3):
    a, b, u, t = fit(d, kappa, tau); e = d.y.values - u; T = len(d)
    out_b, out_a = [], []
    for _ in range(B):
        idx = []
        while len(idx) < T:
            s0 = rng.integers(0, T - L + 1); idx.extend(range(s0, s0 + L))
        dd = d.copy(); dd["y"] = u + e[np.array(idx[:T])]
        a2, b2 = fw.fit_smooth(dd, t, kappa=kappa, tau=tau)
        out_b.append(b2.reindex(t).values); out_a.append(a2)
    return np.array(out_b), np.array(out_a), t

# ---------------- India main fit ----------------
di = prep.india()
a, b, u, t = fit(di, KAPPA_IN)
bb, ba, _ = block_bootstrap(di, KAPPA_IN)
# smoothness profile of the coefficients (identification analysis)
prof = []
for lab, d0, kk in (("India e-2W", di, None), ("China NEV", prep.china(), None)):
    for kap in (1.0, 3.0, 10.0, 30.0, 100.0, 300.0, 1000.0):
        _, bk, uk, tk = fit(d0, kap)
        r = dict(market=lab, kappa=kap, mae_pp=float(100 * np.mean(np.abs(fw.sigma(uk) - d0.s))))
        r.update({c: float(bk.get(c, 0.0)) for c in TERMS}); prof.append(r)
pd.DataFrame(prof).to_csv("results/kappa_profile.csv", index=False)
coef = pd.DataFrame({"estimate": b.reindex(t), "lo": np.quantile(bb, 0.05, 0), "hi": np.quantile(bb, 0.95, 0),
                     "selected_share": (np.abs(bb) > 0).mean(0)}, index=t)
coef.to_csv("results/india_coefficients.csv")
fitted = fw.sigma(u)
R["india_learning_mae_pp"] = float(100 * np.mean(np.abs(fitted - di.s)))
R["india_mean_share_pct"] = float(100 * di.s.mean())
pd.DataFrame({"yyyymm": di.yyyymm, "s": di.s, "fit": fitted, "a": a, "a_lo": np.quantile(ba, 0.05, 0),
              "a_hi": np.quantile(ba, 0.95, 0), "x": di.x, "xlag": di.xlag, "S": di.S,
              "policy": fw.library(di, t)[[c for c in ("S", "S1", "S2", "Sx", "G", "L") if c in t]].values @ b[[c for c in ("S", "S1", "S2", "Sx", "G", "L") if c in t]].values,
              "calendar": fw.library(di, t)[[c for c in ("pre", "fest", "march", "covid") if c in t]].values @ b[[c for c in ("pre", "fest", "march", "covid") if c in t]].values,
              "network": fw.library(di, t)[[c for c in ("x", "x2") if c in t]].values @ b[[c for c in ("x", "x2") if c in t]].values if any(c in t for c in ("x", "x2")) else 0.0}
             ).to_csv("results/india_decomposition.csv", index=False)

# learning comparison: smooth vs two-stage window (w=6, 12) vs fixed
learn = {}
for name, cfg in {"Proposed smooth TV": dict(mode="smooth"), "Two-stage window TV (w=6)": dict(mode="block", window=6),
                  "Two-stage window TV (w=12)": dict(mode="block", window=12), "Fixed coefficients": dict(mode="fixed")}.items():
    for lab, d, kk in (("India e-2W", di, KAPPA_IN), ("China NEV", prep.china(), KAPPA_CN)):
        cfg2 = dict(cfg); cfg2.setdefault("kappa", kk)
        m = fw.TVPayoffModel(terms_for(d), tau=TAU, **cfg2).fit(d)
        learn[(name, lab)] = float(100 * np.mean(np.abs(m.in_sample() - d.s)))
pd.Series(learn).unstack().to_csv("results/learning_mae.csv")

# ---------------- robustness ----------------
rob = []
for kwh, price in ((2.5, 100000.0), (3.0, 120000.0), (3.5, 140000.0)):
    for k_ref in (3, 6, 12):
        dd = prep.india(kwh=kwh, price=price, k_ref=k_ref)
        for kappa in (3.0, 10.0, 30.0):
            for tau in (0.01, 0.02, 0.05):
                _, bx, _, tx = fit(dd, kappa, tau)
                r = dict(kwh=kwh, price=price, k_ref=k_ref, kappa=kappa, tau=tau)
                r.update({c: float(bx.get(c, 0.0)) for c in TERMS}); rob.append(r)
rob = pd.DataFrame(rob); rob.to_csv("results/robustness.csv", index=False)

# ---------------- placebo: electric cars, no central demand incentive for private cars ----------------
dl = prep.india(segment="lmv")
# the e-2W subsidy path is assigned to the car segment as a placebo treatment
dl["S"], dl["G"], dl["L"], dl["pre"] = di.S.values, di.G.values, di.L.values, di.pre.values
al, bl, ul, tl = fit(dl, KAPPA_IN)
bbl, _, _ = block_bootstrap(dl, KAPPA_IN, B=300)
pd.DataFrame({"estimate": bl.reindex(tl), "lo": np.quantile(bbl, 0.05, 0), "hi": np.quantile(bbl, 0.95, 0)}, index=tl).to_csv("results/placebo_cars.csv")

# ---------------- China fit ----------------
dc = prep.china()
ac, bc, uc, tcn = fit(dc, KAPPA_CN)
bbc, bac, _ = block_bootstrap(dc, KAPPA_CN, B=300)
pd.DataFrame({"estimate": bc.reindex(tcn), "lo": np.quantile(bbc, 0.05, 0), "hi": np.quantile(bbc, 0.95, 0),
              "selected_share": (np.abs(bbc) > 0).mean(0)}, index=tcn).to_csv("results/china_coefficients.csv")
R["china_learning_mae_pp"] = float(100 * np.mean(np.abs(fw.sigma(uc) - dc.s)))
pd.DataFrame({"yyyymm": dc.yyyymm, "s": dc.s, "fit": fw.sigma(uc), "a": ac, "a_lo": np.quantile(bac, 0.05, 0),
              "a_hi": np.quantile(bac, 0.95, 0), "x": dc.x, "xlag": dc.xlag, "S": dc.S}).to_csv("results/china_decomposition.csv", index=False)

# ---------------- event magnitudes in the raw data ----------------
def pct(d, m): return float(100 * d.s[d.yyyymm == m].values[0])
R["events"] = {"india_202105": pct(di, 202105), "india_202107": pct(di, 202107), "india_202304": pct(di, 202304),
               "india_202305": pct(di, 202305), "india_202306": pct(di, 202306), "india_202403": pct(di, 202403),
               "india_202404": pct(di, 202404), "india_202503": pct(di, 202503), "india_202504": pct(di, 202504),
               "india_202506": pct(di, 202506),
               "china_202511": pct(dc, 202511), "china_202512": pct(dc, 202512), "china_202601": pct(dc, 202601),
               "china_202602": pct(dc, 202602), "china_202603": pct(dc, 202603), "china_202604": pct(dc, 202604),
               "china_202608": pct(dc, 202608), "china_202508": pct(dc, 202508)}

# ---------------- subsidy-independence margin ----------------
# m_t = a_t + network terms - logit(x_{t-1}); fleet grows without subsidy and calendar effects iff m_t > 0
def margin(d, a_path, bvec, tt):
    net = sum(bvec[c] * fw.library(d, [c])[c].values for c in ("x", "x2") if c in tt and bvec[c] != 0) if any(c in tt for c in ("x", "x2")) else 0.0
    return a_path + net - np.log(d.xlag.values / (1 - d.xlag.values))
# conservative test: rigid baseline (kappa=1000) attributes the largest persistent effect to subsidies
KC = 1000.0
a_c, b_c, u_c, t_c = fit(di, KC); bb_c, ba_c, _ = block_bootstrap(di, KC, B=300)
mi = margin(di, a_c, b_c, t_c)
mi_bs = np.array([margin(di, ba_c[k], pd.Series(bb_c[k], index=t_c), t_c) for k in range(len(ba_c))])
R["india_conservative_coef"] = {k: float(v) for k, v in b_c.items()}
a_cc, b_cc, _, t_cc = fit(dc, KC); bb_cc, ba_cc, _ = block_bootstrap(dc, KC, B=300)
mc = margin(dc, a_cc, b_cc, t_cc)
mc_bs = np.array([margin(dc, ba_cc[k], pd.Series(bb_cc[k], index=t_cc), t_cc) for k in range(len(ba_cc))])
R["china_conservative_coef"] = {k: float(v) for k, v in b_cc.items()}
pd.DataFrame({"yyyymm": di.yyyymm, "m": mi, "lo": np.quantile(mi_bs, 0.05, 0), "hi": np.quantile(mi_bs, 0.95, 0),
              "s0": fw.sigma(mi + np.log(di.xlag / (1 - di.xlag))), "xlag": di.xlag}).to_csv("results/india_margin.csv", index=False)
pd.DataFrame({"yyyymm": dc.yyyymm, "m": mc, "lo": np.quantile(mc_bs, 0.05, 0), "hi": np.quantile(mc_bs, 0.95, 0),
              "s0": fw.sigma(mc + np.log(dc.xlag / (1 - dc.xlag))), "xlag": dc.xlag}).to_csv("results/china_margin.csv", index=False)
R["india_margin_last"] = [float(mi[-1]), float(np.quantile(mi_bs[:, -1], 0.05)), float(np.quantile(mi_bs[:, -1], 0.95))]
R["india_s0_last_pct"] = float(100 * fw.sigma(mi[-1] + np.log(di.xlag.values[-1] / (1 - di.xlag.values[-1]))))
R["india_xlag_last_pct"] = float(100 * di.xlag.values[-1])
pos = np.where(np.quantile(mi_bs, 0.05, 0) > 0)[0]
R["india_margin_first_robust_positive"] = int(di.yyyymm.values[pos[0]]) if len(pos) else None
R["india_margin_robust_positive_all_after"] = bool(len(pos) and np.all(np.quantile(mi_bs, 0.05, 0)[pos[0]:] > 0))
R["china_margin_last"] = [float(mc[-1]), float(np.quantile(mc_bs[:, -1], 0.05)), float(np.quantile(mc_bs[:, -1], 0.95))]

# ---------------- counterfactual subsidy paths, India, June 2023 to June 2025 ----------------
i0 = int(np.where(di.yyyymm == 202306)[0][0]); T = len(di); n_cf = T - i0
S_pre = float(di.S.values[i0 - 1])
paths = {"Actual path": di.S.values[i0:].copy(),
         "Maintain May 2023 level": np.repeat(S_pre, n_cf),
         "Linear taper to zero by June 2025": np.linspace(S_pre, 0, n_cf + 1)[1:],
         "Abrupt withdrawal in June 2023": np.zeros(n_cf)}
def simulate(Spath, keep_pre, a=a, b=b, t=t):
    d = di.copy(); S = d.S.values.copy(); S[i0:] = Spath; d["S"] = S
    Rf = prep.reference(S, 6); d["R"] = Rf; d["G"] = np.maximum(S - Rf, 0); d["L"] = np.minimum(S - Rf, 0)
    # pull-forward month: actual path keeps all three announced cuts; an abrupt withdrawal in June 2023
    # keeps the May 2023 announcement month only; the status quo and the monthly taper have none
    if keep_pre == "Abrupt withdrawal in June 2023": d.loc[d.index >= i0, "pre"] = 0.0
    elif keep_pre != "Actual path": d.loc[d.index >= i0 - 1, "pre"] = 0.0
    M, E = di.M.values[i0 - 1], di.E.values[i0 - 1]; s_out = []
    for h in range(i0, T):
        row = d.iloc[[h]].copy(); row["xlag"] = E / M
        uu = a[h] + fw.library(row, t).values @ b.values
        s = float(fw.sigma(uu)[0]); s_out.append(s); M += row.n.values[0]; E += s * row.n.values[0]
    return np.array(s_out)
price = 120000.0
cf_all, traj_all = {}, {}
for kap in (KAPPA_IN, 100.0, 1000.0):
  ak, bk, uk, tk = fit(di, kap)
  cf = {}; trajs = {"yyyymm": di.yyyymm.values[i0:]}
  for name, Sp in paths.items():
    sp = simulate(Sp, keep_pre=name, a=ak, b=bk, t=tk)
    ev = sp * di.n.values[i0:]
    outlay = float(np.sum(Sp / 100 * price * ev))
    cf[name] = dict(ev_units=float(ev.sum()), outlay_crore=outlay / 1e7, mean_share_pct=float(100 * sp.mean()),
                    end_share_pct=float(100 * sp[-1]))
    trajs[name] = sp; trajs[name + " S"] = Sp
  base = cf["Abrupt withdrawal in June 2023"]
  for k, v in cf.items():
    add = v["ev_units"] - base["ev_units"]
    v["additional_ev_vs_withdrawal"] = add
    v["outlay_per_additional_ev_rs"] = (v["outlay_crore"] * 1e7 / add) if add > 0 else None
  cf_all[f"kappa={kap:g}"] = cf
  pd.DataFrame(trajs).to_csv(f"results/counterfactual_paths_k{kap:g}.csv", index=False)
R["counterfactual"] = cf_all
R["observed_ev_units_cf_window"] = float(di.e.values[i0:].sum())
R["kappa_india"], R["kappa_china"] = KAPPA_IN, KAPPA_CN

# beta-based counterfactual odds ratio (Proposition 2): long-run effect of one percentage point
R["india_coef"] = {k: float(v) for k, v in b.items()}; R["china_coef"] = {k: float(v) for k, v in bc.items()}
json.dump(R, open("results/summary.json", "w"), indent=1)
np.savez("results/bootstrap_draws.npz", india=bb, india_terms=np.array(t), china=bbc, china_terms=np.array(tcn), placebo=bbl, placebo_terms=np.array(tl))
print(coef.round(4)); print(pd.read_csv("results/china_coefficients.csv").round(4)); print(pd.read_csv("results/placebo_cars.csv").round(4))
print(json.dumps(R, indent=1)[:6000]); print(pd.read_csv("results/learning_mae.csv"))
