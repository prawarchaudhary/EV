"""Rewrite styles.xml of the final docx: Times New Roman everywhere, black headings, sizes, 1.5 spacing."""
import re, sys, zipfile, shutil
src, dst = sys.argv[1], sys.argv[2]
zin = zipfile.ZipFile(src); s = zin.read("word/styles.xml").decode()
TNR = '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="Times New Roman" w:cs="Times New Roman"/>'
s = re.sub(r'<w:rFonts [^>]*/>', TNR, s)
s = re.sub(r'<w:color w:themeColor="[^"]*" w:val="[^"]*"/>', '<w:color w:val="000000"/>', s)
def patch(style_id, size=None, spacing=None, jc=None, italic=None):
    global s
    m = re.search(rf'<w:style [^>]*w:styleId="{style_id}"[^>]*>.*?</w:style>', s, re.S)
    if not m: print("missing", style_id); return
    blk = m.group(0); new = blk
    if size:
        new = re.sub(r'<w:sz w:val="\d+"/>', f'<w:sz w:val="{size}"/>', new)
        new = re.sub(r'<w:szCs w:val="\d+"/>', f'<w:szCs w:val="{size}"/>', new)
        if '<w:sz ' not in new:
            new = new.replace('</w:rPr>', f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/></w:rPr>') if '<w:rPr>' in new else new.replace('</w:style>', f'<w:rPr>{TNR}<w:sz w:val="{size}"/><w:szCs w:val="{size}"/></w:rPr></w:style>')
    if spacing:
        new = re.sub(r'<w:spacing [^>]*/>', spacing, new)
        if '<w:spacing ' not in new:
            if '<w:pPr>' in new: new = new.replace('<w:pPr>', '<w:pPr>' + spacing, 1)
            else: new = new.replace('<w:rPr>', '<w:pPr>' + spacing + '</w:pPr><w:rPr>', 1) if '<w:rPr>' in new else new.replace('</w:style>', '<w:pPr>' + spacing + '</w:pPr></w:style>')
    if jc:
        new = re.sub(r'<w:jc w:val="[^"]*"/>', '', new)
        new = new.replace(spacing, spacing + f'<w:jc w:val="{jc}"/>') if spacing else new
    if italic is False: new = new.replace('<w:i/>', '').replace('<w:iCs/>', '')
    s = s.replace(blk, new)
body_sp = '<w:spacing w:before="0" w:after="120" w:line="360" w:lineRule="auto"/>'
for sid in ("BodyText", "FirstParagraph"):
    patch(sid, 22, body_sp, "both")
patch("Compact", 22, body_sp, "left")
patch("Title", 32, '<w:spacing w:before="0" w:after="240" w:line="276" w:lineRule="auto"/>', "left")
patch("Heading1", 26, '<w:spacing w:before="360" w:after="120" w:line="276" w:lineRule="auto"/>')
patch("Heading2", 23, '<w:spacing w:before="240" w:after="80" w:line="276" w:lineRule="auto"/>')
patch("ImageCaption", 19, '<w:spacing w:before="60" w:after="240" w:line="240" w:lineRule="auto"/>', "left", italic=False)
patch("TableCaption", 19, '<w:spacing w:before="240" w:after="60" w:line="240" w:lineRule="auto"/>', "left", italic=False)
patch("Caption", 19, None, None, italic=False)
# default run size 11 pt
s = re.sub(r'(<w:docDefaults>.*?<w:rPrDefault><w:rPr>)', r'\1', s, flags=re.S)
zout = zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED)
for it in zin.infolist():
    if it.filename.endswith('/'): continue
    data = s.encode() if it.filename == "word/styles.xml" else zin.read(it.filename)
    zout.writestr(it, data)
zout.close(); print("ok")
