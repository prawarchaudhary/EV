---
title: "Internal referee report and response to the review"
subtitle: "Learning the payoff of going electric: data-driven evolutionary dynamics of subsidy phase-out under dual carbon goals"
---

# Referee report

The manuscript proposes learning the payoff of an evolutionary adoption game from aggregate registration data, using logit dynamics with a smooth baseline and a sparse, sign-constrained library of policy terms, and applies it to Indian electric two-wheelers and Chinese new energy vehicles. The question is relevant to policy and to the behavioural operations literature, the data are documented carefully, and the authors are open about the identification problem between persistent subsidy effects and the baseline. The simulation study is a welcome addition. My main concerns are that several headline statements are stronger than the evidence supports, that the forecasting comparison lacks inference, and that the conservative test of subsidy independence is not conservative in one of the two markets. I list major and minor comments below.

## Major comments

**1. Forecast superiority is asserted without inference.** The abstract and conclusion state that the method forecasts more accurately than eight alternatives, yet the Indian error of 0.92 points is almost identical to that of gradient boosting (0.95) and SARIMAX (1.04), and the evaluation rests on 18 and 12 forecasts. Formal tests of equal predictive accuracy are needed, and the claims should follow their results.

**2. The subsidy-independence test is called conservative without being shown to be so.** The margin is evaluated only at $\kappa = 1000$ on the argument that a rigid baseline assigns the largest persistent effect to the subsidy. A very flexible baseline can also lower the margin or widen its band. The authors should report the margin across the full bracket of $\kappa$ and base their conclusions on what holds at every value.

**3. The behavioural conclusion is overstated for India.** The abstract says that reductions act mainly through a transient loss response, but for India the loss coefficient has a bootstrap interval that includes zero, it vanishes at $\kappa = 1000$, and the simulation shows that transient and persistent effects are only partly separable. The two markets should be described separately.

**4. The evolutionary framing needs to be stated precisely.** Equation (1) is an accounting identity, and equation (2) is inverted to observe the payoff, so in the Indian application, where no installed-base term is retained, the model is a logit regression with a smooth intercept. The authors should say this and explain where the evolutionary structure still matters. The statement about rest points and vanishing noise is also imprecise.

**5. The learning-error comparison is not adjusted for complexity.** A smooth baseline with $T$ free values will fit better in sample than a window model. Effective degrees of freedom should be reported and the comparison made at similar complexity.

**6. The empirical check of proposition 1 is close to tautological.** If the payoff error is measured by the realised logit error, the bound with $\ell = 0$ follows from the mean value theorem and cannot fail. The text should present figure 12 as an illustration of error damping rather than as a confirmation of the bound.

**7. Causal language and confounding.** Subsidy changes coincided with price and model changes by manufacturers, and their timing may have responded to adoption. The loss coefficient is therefore a reduced-form response, and the limitations should say so.

**8. Inference after thresholding and residual dependence.** Percentile intervals for thresholded coefficients are not exact confidence intervals, as the Chinese $x^2$ estimate lying outside its own interval shows. The residuals also show twelve-month autocorrelation, which three-month blocks do not capture. Sensitivity to the block length should be reported.

**9. Interpretation of the margin.** A positive margin means that the subsidy-free choice share exceeds the installed-base share, not that the choice share would keep rising. The installed base is also counted from the start of the sample. The direction in which this affects the test should be explained.

## Minor comments

10. Proposition 2 states that the estimation error is at most a quantity to which it is in fact equal.
11. The counterfactuals hold total registrations and the baseline fixed. These assumptions should be stated where the results are reported.
12. The six-month adjustment period of the reference subsidy is assumed, but table 8 and section 6 read as if it were estimated.
13. The reason the Indian sample ends in June 2025, the meaning of lakh and crore, and the cap on the Chinese exemption should be stated.
14. Forecasts use observed market size in the test months. The authors should state whether this advantages the proposed model.
15. The abstract is too long for most management journals, and the gains from forecast combination are not tested.
16. The phrase that the phase dependence of [11] is "now estimated rather than assumed" overstates what the data identify.

# Response to the review

We thank the referee for a careful report. Every comment has been addressed, in several cases with new analyses that changed the claims of the paper. New results are produced by `code/review_checks.py` and reported in section S8 of the electronic supplementary material (tables S13 to S16). Section numbers below refer to the revised manuscript.

**Comment 1.** We added Diebold and Mariano tests with the Harvey, Leybourne and Newbold small-sample correction, together with Wilcoxon signed-rank tests, comparing the combined forecast with every alternative (table S15). The combined forecast is significantly more accurate than the two-stage window model ($p = 0.002$ in India and 0.022 in China) and the fixed-coefficient model ($p = 0.022$ and 0.019). Its advantage over gradient boosting, SARIMAX and the logistic trend is not significant at the 10 per cent level in either market, and the gain over the single selected configuration is not significant either. The abstract, section 4.3, the discussion and the conclusion now say that the model forecasts at least as well as flexible statistical benchmarks rather than better than them. References [40] and [41] were added.

**Comment 2.** The referee is right, and this changed a conclusion. We recomputed the margin and its bootstrap band at $\kappa = 1, 10, 100$ and 1000 (figure 11, redrawn, and table S16). For India the lower bound is positive in every month from June 2023 at all four values, so the Indian conclusion stands. For China the margin is positive throughout the sample at $\kappa \ge 10$, but at the cross-validated $\kappa = 1$ the point estimate is negative in early 2025 and the lower bound is positive only in July and August 2026. We removed the claim that the Chinese margin is positive throughout the sample from the abstract, section 4.6, table 8 and the conclusion, and we now state that the Chinese evidence is robust only at the end of the sample. Section 6 now recommends evaluating the margin across a range of smoothness rather than at a single value.

**Comment 3.** The abstract and conclusion now distinguish the markets. They state that in China the reduction acted through a transient loss response, and that in India the data are consistent either with such a response or with a small persistent effect in the nascent phase.

**Comment 4.** Section 2.1 now states that equation (1) is an accounting identity and that the behavioural content lies in equation (2) and the payoff specification. It explains that the payoff is observed in logit units once equation (2) is inverted, and that without installed-base terms the model reduces to a logit regression with a smoothly varying intercept, the evolutionary structure entering through the accumulated installed base on which the policy analysis rests. The inverse transform was moved out of equation (2), and the rest-point statement was corrected.

**Comment 5.** We computed the trace of the hat matrix for every model (table S14). The Indian model at $\kappa = 10$ uses 20.6 effective parameters against 20 for the six-month window model, so the threefold reduction in learning error is not due to added flexibility. The selected Chinese model is more flexible (15.2 against 9), so section 4.3 now makes the fair comparison at $\kappa = 10$ (9.3 parameters), where the learning error of 1.10 points is still below the 1.60 points of the window model. The discussion now says "about three times in India and about a third in China" instead of "two to four times".

**Comment 6.** Section 4.7 now explains that, because the true baseline is unknown, the payoff error is measured by the realised logit error and the bound then holds by construction, so figure 12 illustrates the strength of error damping rather than testing the bound.

**Comment 7.** Section 4.2 now describes the loss coefficient as a reduced-form response that includes pass-through and cannot be separated from simultaneous price or model changes. The limitations paragraph adds the non-random timing of reductions and the assumed adjustment period.

**Comment 8.** We repeated the Indian bootstrap with blocks of six and twelve months (table S13). The loss interval becomes [0, 0.026] and [0, 0.030], against [0, 0.029] with three-month blocks, and retention rates change little. Section 4.2 now notes that intervals after thresholding describe the variability of the whole selection procedure, and explains why the Chinese $x^2$ estimate lies outside its interval. Section S4 refers to the new check.

**Comment 9.** Section 4.6 now states that a positive margin shows that withdrawal would slow rather than reverse the transition, not that the choice share would keep rising. It also explains that counting the installed base from the start of the sample overstates the electric share of the full stock, which raises the threshold and makes the test conservative in this respect. The observed share in June 2025 (7.3 per cent) is now reported beside the subsidy-free share (6.1 per cent).

**Comment 10.** Corrected to "equals".

**Comment 11.** Section 4.5 now states both assumptions next to table 7.

**Comment 12.** Table 8 and the limitations now describe the six-month adjustment period as an assumption, noting that the loss response is stable for windows of three to twelve months.

**Comment 13.** Section 3.1 now explains that June 2025 is the latest month in the compiled series and defines lakh and crore. Section 3.2 notes that the cap means the coded value overstates relief for expensive vehicles, while the proportional halving applies at every price.

**Comment 14.** Section 2.4 now states that observed market size affects the forecasts only through installed-base terms, so it plays no role in India and a minor role in China.

**Comment 15.** The abstract was shortened from 366 to 284 words. Section 4.3 and the discussion now report that the gains from combination over a single selected configuration are not statistically significant ($p = 0.13$ and 0.58).

**Comment 16.** The phrase was replaced by a statement that the data constrain the phase pattern only within the identification bracket. The introduction now says that the methodological extensions address the concerns raised for the window-based approach "at least in part".

**Remaining limitations.** Some concerns cannot be resolved with the present data and are stated as limitations rather than fixed. The Chinese sample contains a single policy change, the Indian series ends in June 2025, the analysis is national rather than regional, and persistent subsidy effects remain identified only within a bracket. These points are set out in section 5.
